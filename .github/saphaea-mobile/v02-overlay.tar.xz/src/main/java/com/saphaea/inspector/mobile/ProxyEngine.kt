package com.saphaea.inspector.mobile

import android.content.Context
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.*
import java.net.*
import java.security.KeyStore
import java.util.concurrent.Executors
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import kotlin.concurrent.thread

class ProxyEngine(private val context: Context) {
    private var server: ServerSocket? = null
    @Volatile private var running = false
    @Volatile var inspectHttps = false
    private val pool = Executors.newCachedThreadPool()
    private val client = OkHttpClient.Builder().followRedirects(false).followSslRedirects(false).build()
    val ca = CertificateAuthority(context)

    fun start(port: Int, inspect: Boolean): Result<Unit> = runCatching {
        if (running) stop()
        inspectHttps = inspect
        server = ServerSocket().apply { bind(InetSocketAddress(InetAddress.getLoopbackAddress(), port)) }
        running = true
        AppState.proxyPort = port
        AppState.proxyRunning = true
        AppState.changed()
        thread(name = "SaphaeaProxyAccept") {
            while (running) {
                try {
                    val socket = server?.accept() ?: break
                    pool.submit { handle(socket) }
                } catch (_: Exception) { if (!running) break }
            }
        }
    }

    fun stop() {
        running = false
        AppState.proxyRunning = false
        AppState.changed()
        try { server?.close() } catch (_: Exception) {}
        server = null
    }

    private fun handle(socket: Socket) {
        socket.soTimeout = 20_000
        try {
            val input = BufferedInputStream(socket.getInputStream())
            val output = BufferedOutputStream(socket.getOutputStream())
            val requestLine = readLine(input) ?: return
            if (requestLine.isBlank()) return
            val parts = requestLine.split(' ', limit = 3)
            if (parts.size < 2) return
            if (parts[0].equals("CONNECT", true)) {
                val hp = parts[1].split(':', limit = 2)
                val host = hp[0]
                val port = hp.getOrNull(1)?.toIntOrNull() ?: 443
                // Consume CONNECT headers.
                while (true) { val l = readLine(input) ?: break; if (l.isBlank()) break }
                if (inspectHttps) inspectConnect(socket, output, host, port) else tunnelConnect(socket, output, host, port)
            } else {
                handleHttp(socket, input, output, requestLine, false, null)
            }
        } catch (_: Exception) {
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private fun tunnelConnect(clientSocket: Socket, output: OutputStream, host: String, port: Int) {
        val started = System.currentTimeMillis()
        val remote = Socket()
        try {
            remote.connect(InetSocketAddress(host, port), 7000)
            output.write("HTTP/1.1 200 Connection Established\r\nProxy-Agent: Saphaea-Inspector-Mobile/0.2\r\n\r\n".toByteArray())
            output.flush()
            AppState.proxySessions.add(0, ProxySession(method = "CONNECT", url = "https://$host:$port", status = 200, type = "HTTPS TUNNEL", durationMs = System.currentTimeMillis() - started))
            AppState.changed()
            val t = thread { copy(clientSocket.getInputStream(), remote.getOutputStream()) }
            copy(remote.getInputStream(), clientSocket.getOutputStream())
            try { t.join(500) } catch (_: Exception) {}
        } catch (e: Exception) {
            try { output.write("HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\n\r\n".toByteArray()); output.flush() } catch (_: Exception) {}
        } finally { try { remote.close() } catch (_: Exception) {} }
    }

    private fun inspectConnect(rawSocket: Socket, output: OutputStream, host: String, port: Int) {
        try {
            output.write("HTTP/1.1 200 Connection Established\r\nProxy-Agent: Saphaea-Inspector-Mobile/0.2\r\n\r\n".toByteArray())
            output.flush()
            val (privateKey, chain) = ca.hostIdentity(host)
            val ks = KeyStore.getInstance(KeyStore.getDefaultType()).apply {
                load(null)
                setKeyEntry("host", privateKey, "mobile".toCharArray(), chain)
            }
            val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()).apply { init(ks, "mobile".toCharArray()) }
            val sslContext = SSLContext.getInstance("TLS").apply { init(kmf.keyManagers, null, null) }
            val ssl = sslContext.socketFactory.createSocket(rawSocket, host, port, false) as SSLSocket
            ssl.useClientMode = false
            ssl.enabledProtocols = ssl.supportedProtocols.filter { it == "TLSv1.3" || it == "TLSv1.2" }.toTypedArray()
            ssl.startHandshake()
            val sin = BufferedInputStream(ssl.inputStream)
            val sout = BufferedOutputStream(ssl.outputStream)
            val line = readLine(sin) ?: return
            handleHttp(ssl, sin, sout, line, true, host)
        } catch (e: Exception) {
            AppState.proxySessions.add(0, ProxySession(method = "CONNECT", url = "https://$host:$port", status = 0, type = "HTTPS INSPECTION ERROR", observation = e.message ?: "TLS inspection failed"))
            AppState.changed()
        }
    }

    private fun handleHttp(socket: Socket, input: BufferedInputStream, output: BufferedOutputStream, requestLine: String, tls: Boolean, forcedHost: String?) {
        val started = System.currentTimeMillis()
        val p = requestLine.split(' ', limit = 3)
        if (p.size < 2) return
        val method = p[0].uppercase()
        val target = p[1]
        val headers = linkedMapOf<String, String>()
        while (true) {
            val line = readLine(input) ?: break
            if (line.isBlank()) break
            val idx = line.indexOf(':')
            if (idx > 0) headers[line.substring(0, idx).trim()] = line.substring(idx + 1).trim()
        }
        val contentLength = headers.entries.firstOrNull { it.key.equals("Content-Length", true) }?.value?.toIntOrNull() ?: 0
        val bodyBytes = if (contentLength > 0 && contentLength <= 10_000_000) input.readNBytesCompat(contentLength) else ByteArray(0)
        val hostHeader = forcedHost ?: headers.entries.firstOrNull { it.key.equals("Host", true) }?.value?.substringBefore(':')
        val url = when {
            target.startsWith("http://") || target.startsWith("https://") -> target
            hostHeader != null -> "${if (tls) "https" else "http"}://$hostHeader${if (target.startsWith("/")) target else "/$target"}"
            else -> return
        }
        val reqBuilder = Request.Builder().url(url)
        headers.forEach { (k, v) ->
            if (!k.equals("Host", true) && !k.equals("Content-Length", true) && !k.equals("Proxy-Connection", true) && !k.equals("Connection", true)) {
                try { reqBuilder.addHeader(k, v) } catch (_: Exception) {}
            }
        }
        val body = if (method in setOf("POST", "PUT", "PATCH", "DELETE") || bodyBytes.isNotEmpty()) bodyBytes.toRequestBody(headers["Content-Type"]?.toMediaTypeOrNull()) else null
        reqBuilder.method(method, body)
        try {
            client.newCall(reqBuilder.build()).execute().use { response ->
                val bytes = response.body?.bytes() ?: ByteArray(0)
                val responseHeaders = StringBuilder()
                response.headers.forEach { (k, v) -> responseHeaders.append(k).append(": ").append(v).append('\n') }
                val statusLine = "HTTP/1.1 ${response.code} ${response.message}\r\n"
                output.write(statusLine.toByteArray())
                response.headers.forEach { (k, v) ->
                    if (!k.equals("Content-Length", true) && !k.equals("Transfer-Encoding", true) && !k.equals("Connection", true) && !k.equals("Content-Encoding", true)) {
                        output.write("$k: $v\r\n".toByteArray())
                    }
                }
                output.write("Content-Length: ${bytes.size}\r\nConnection: close\r\n\r\n".toByteArray())
                output.write(bytes)
                output.flush()
                val reqHeadersText = headers.entries.joinToString("\n") { "${it.key}: ${it.value}" }
                val obs = analyzeHeaders(response.headers)
                AppState.proxySessions.add(0, ProxySession(
                    method = method,
                    url = url,
                    status = response.code,
                    type = if (tls) "HTTPS INSPECTED" else "HTTP",
                    requestHeaders = reqHeadersText,
                    requestBody = bodyBytes.toString(Charsets.UTF_8).take(200_000),
                    responseHeaders = responseHeaders.toString().trim(),
                    responseBody = bytes.toString(Charsets.UTF_8).take(300_000),
                    durationMs = System.currentTimeMillis() - started,
                    observation = obs
                ))
                while (AppState.proxySessions.size > 500) AppState.proxySessions.removeAt(AppState.proxySessions.lastIndex)
                AppState.changed()
            }
        } catch (e: Exception) {
            try { output.write("HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\n\r\n".toByteArray()); output.flush() } catch (_: Exception) {}
            AppState.proxySessions.add(0, ProxySession(method = method, url = url, status = 502, type = if (tls) "HTTPS INSPECTED" else "HTTP", durationMs = System.currentTimeMillis() - started, observation = e.message ?: "Upstream request failed"))
            AppState.changed()
        }
    }

    private fun analyzeHeaders(headers: Headers): String {
        val notes = mutableListOf<String>()
        if (headers["Strict-Transport-Security"].isNullOrBlank()) notes += "No HSTS"
        if (headers["Content-Security-Policy"].isNullOrBlank()) notes += "No CSP"
        if (headers["X-Content-Type-Options"].isNullOrBlank()) notes += "No X-Content-Type-Options"
        if (headers["Referrer-Policy"].isNullOrBlank()) notes += "No Referrer-Policy"
        headers.values("Set-Cookie").forEach { c ->
            if (!c.contains("Secure", true)) notes += "Cookie without Secure"
            if (!c.contains("HttpOnly", true)) notes += "Cookie without HttpOnly"
        }
        return notes.distinct().joinToString(" • ")
    }

    fun repeat(method: String, url: String, headersText: String, bodyText: String): String {
        val started = System.currentTimeMillis()
        val builder = Request.Builder().url(url)
        var contentType: String? = null
        headersText.lineSequence().forEach { line ->
            val idx = line.indexOf(':')
            if (idx > 0) {
                val k = line.substring(0, idx).trim()
                val v = line.substring(idx + 1).trim()
                if (k.equals("Content-Type", true)) contentType = v
                try { builder.addHeader(k, v) } catch (_: Exception) {}
            }
        }
        val m = method.uppercase()
        val body = if (m in setOf("POST", "PUT", "PATCH", "DELETE") || bodyText.isNotEmpty()) {
            bodyText.toRequestBody((contentType ?: "text/plain; charset=utf-8").toMediaType())
        } else null
        builder.method(m, body)
        return try {
            client.newCall(builder.build()).execute().use { r ->
                val raw = r.body?.bytes() ?: ByteArray(0)
                val bodyTextOut = raw.toString(Charsets.UTF_8).take(500_000)
                val duration = System.currentTimeMillis() - started
                val observations = analyzeHeaders(r.headers)
                val server = r.header("Server").orEmpty()
                val type = r.header("Content-Type").orEmpty()
                val location = r.header("Location").orEmpty()
                buildString {
                    appendLine("${r.code} ${r.message}    ${duration} ms")
                    appendLine("Saphaea analysis: ${raw.size} B${if (type.isNotBlank()) " • $type" else ""}${if (server.isNotBlank()) " • server=$server" else ""}")
                    if (location.isNotBlank()) appendLine("Redirect/location: $location")
                    if (observations.isNotBlank()) appendLine("Observations: $observations")
                    appendLine()
                    r.headers.forEach { (k, v) -> appendLine("$k: $v") }
                    appendLine(); append(bodyTextOut)
                }
            }
        } catch (e: Exception) { "Request failed: ${e.message}" }
    }

    private fun readLine(input: InputStream): String? {
        val out = ByteArrayOutputStream()
        while (out.size() < 32_768) {
            val b = input.read()
            if (b < 0) return if (out.size() == 0) null else out.toString("ISO-8859-1")
            if (b == '\n'.code) break
            if (b != '\r'.code) out.write(b)
        }
        return out.toString("ISO-8859-1")
    }

    private fun InputStream.readNBytesCompat(n: Int): ByteArray {
        val out = ByteArrayOutputStream(n)
        val buf = ByteArray(8192)
        var remaining = n
        while (remaining > 0) {
            val got = read(buf, 0, minOf(buf.size, remaining))
            if (got <= 0) break
            out.write(buf, 0, got); remaining -= got
        }
        return out.toByteArray()
    }

    private fun copy(input: InputStream, output: OutputStream) {
        try { input.copyTo(output, 16 * 1024); output.flush() } catch (_: Exception) {}
    }
}
