package com.saphaea.inspector.mobile

import java.util.concurrent.CopyOnWriteArrayList

data class NetworkDevice(
    val ip: String,
    var host: String = "",
    var mac: String = "",
    var vendor: String = "",
    var latencyMs: Long = -1,
    var role: String = "Device",
    var osHint: String = "",
    var services: String = "",
    var serviceDetails: String = "",
    var webTitle: String = "",
    var exposure: String = "",
    var isGateway: Boolean = false,
    var isLocal: Boolean = false,
    var seenAt: Long = System.currentTimeMillis()
)

data class WifiNetwork(
    val ssid: String,
    val bssid: String,
    val level: Int,
    val frequency: Int,
    val channel: Int,
    val capabilities: String
)

data class PacketRecord(
    val time: Long,
    val version: Int,
    val protocol: String,
    val appProtocol: String = "",
    val source: String,
    val destination: String,
    val sourcePort: Int?,
    val destinationPort: Int?,
    val length: Int,
    val ttlOrHop: Int = -1,
    val tcpFlags: String = "",
    val info: String = "",
    val dnsName: String = "",
    val payloadPreview: String = "",
    val hexPreview: String = "",
    val note: String = ""
)

data class ProxySession(
    val time: Long = System.currentTimeMillis(),
    val method: String,
    val url: String,
    val status: Int,
    val type: String,
    val requestHeaders: String = "",
    val requestBody: String = "",
    val responseHeaders: String = "",
    val responseBody: String = "",
    val durationMs: Long = 0,
    val observation: String = ""
)

object AppState {
    val devices = CopyOnWriteArrayList<NetworkDevice>()
    val wifi = CopyOnWriteArrayList<WifiNetwork>()
    val packets = CopyOnWriteArrayList<PacketRecord>()
    val proxySessions = CopyOnWriteArrayList<ProxySession>()
    @Volatile var proxyRunning = false
    @Volatile var proxyPort = 8080
    @Volatile var vpnCaptureRunning = false
    @Volatile var deepScan = false
    var onStateChanged: (() -> Unit)? = null

    fun changed() {
        onStateChanged?.invoke()
    }
}
