package com.saphaea.inspector.mobile

import android.app.*
import android.content.Intent
import android.net.VpnService
import android.os.IBinder
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.net.InetAddress
import kotlin.concurrent.thread
import kotlin.math.min

class CaptureVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    @Volatile private var running = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            return START_NOT_STICKY
        }
        if (!running) startCapture()
        return START_STICKY
    }

    private fun startCapture() {
        val builder = Builder()
            .setSession("Saphaea Inspector Capture")
            .setMtu(1500)
            .addAddress("10.77.0.1", 24)
            .addRoute("0.0.0.0", 0)
            .addAddress("fd77:73::1", 64)
            .addRoute("::", 0)
        try { builder.addDisallowedApplication(packageName) } catch (_: Exception) {}
        tun = builder.establish() ?: return
        running = true
        AppState.vpnCaptureRunning = true
        AppState.changed()
        startForeground(NOTIFICATION_ID, notification())
        thread(name = "SaphaeaVpnCapture") { captureLoop() }
    }

    private fun captureLoop() {
        val pfd = tun ?: return
        val input = FileInputStream(pfd.fileDescriptor)
        val buffer = ByteArray(32767)
        try {
            while (running) {
                val len = input.read(buffer)
                if (len <= 0) continue
                parsePacket(buffer, len)?.let {
                    AppState.packets.add(0, it)
                    while (AppState.packets.size > 2500) AppState.packets.removeAt(AppState.packets.lastIndex)
                    AppState.changed()
                }
            }
        } catch (_: Exception) {
        } finally {
            try { input.close() } catch (_: Exception) {}
        }
    }

    private fun parsePacket(data: ByteArray, len: Int): PacketRecord? {
        if (len < 20) return null
        val version = (data[0].toInt() ushr 4) and 0x0f
        return when (version) {
            4 -> parseIpv4(data, len)
            6 -> parseIpv6(data, len)
            else -> null
        }
    }

    private fun parseIpv4(d: ByteArray, len: Int): PacketRecord? {
        val ihl = (d[0].toInt() and 0x0f) * 4
        if (ihl < 20 || len < ihl) return null
        val proto = u8(d, 9)
        val src = (12..15).joinToString(".") { u8(d, it).toString() }
        val dst = (16..19).joinToString(".") { u8(d, it).toString() }
        val ttl = u8(d, 8)
        val totalLength = u16(d, 2).takeIf { it > 0 }?.coerceAtMost(len) ?: len
        val identification = u16(d, 4)
        val flagsFrag = u16(d, 6)
        val dontFragment = flagsFrag and 0x4000 != 0
        val moreFragments = flagsFrag and 0x2000 != 0
        val fragOffset = flagsFrag and 0x1fff
        val ipNote = buildString {
            append("IPv4 id=$identification ttl=$ttl")
            if (dontFragment) append(" DF")
            if (moreFragments) append(" MF")
            if (fragOffset > 0) append(" frag=$fragOffset")
        }
        return parseTransport(d, totalLength, 4, proto, ihl, src, dst, ttl, ipNote)
    }

    private fun parseIpv6(d: ByteArray, len: Int): PacketRecord? {
        if (len < 40) return null
        val proto = u8(d, 6)
        val hop = u8(d, 7)
        val src = try { InetAddress.getByAddress(d.copyOfRange(8, 24)).hostAddress ?: "" } catch (_: Exception) { "" }
        val dst = try { InetAddress.getByAddress(d.copyOfRange(24, 40)).hostAddress ?: "" } catch (_: Exception) { "" }
        return parseTransport(d, len, 6, proto, 40, src, dst, hop, "IPv6 hop=$hop next=$proto")
    }

    private fun parseTransport(
        d: ByteArray,
        len: Int,
        version: Int,
        proto: Int,
        off: Int,
        src: String,
        dst: String,
        ttlOrHop: Int,
        ipNote: String
    ): PacketRecord {
        return when (proto) {
            6 -> parseTcp(d, len, version, off, src, dst, ttlOrHop, ipNote)
            17 -> parseUdp(d, len, version, off, src, dst, ttlOrHop, ipNote)
            1, 58 -> parseIcmp(d, len, version, proto, off, src, dst, ttlOrHop, ipNote)
            else -> PacketRecord(
                time = System.currentTimeMillis(), version = version, protocol = "IP/$proto", source = src,
                destination = dst, sourcePort = null, destinationPort = null, length = len,
                ttlOrHop = ttlOrHop, info = ipNote, hexPreview = hex(d, off, len)
            )
        }
    }

    private fun parseTcp(d: ByteArray, len: Int, version: Int, off: Int, src: String, dst: String, ttl: Int, ipNote: String): PacketRecord {
        if (len < off + 20) return PacketRecord(System.currentTimeMillis(), version, "TCP", source = src, destination = dst, sourcePort = null, destinationPort = null, length = len, ttlOrHop = ttl, info = "$ipNote • truncated TCP")
        val sp = u16(d, off)
        val dp = u16(d, off + 2)
        val seq = u32(d, off + 4)
        val ack = u32(d, off + 8)
        val dataOffset = ((u8(d, off + 12) ushr 4) and 0x0f) * 4
        val flagsByte = u8(d, off + 13)
        val flags = tcpFlags(flagsByte)
        val window = u16(d, off + 14)
        val payloadOff = (off + dataOffset).coerceAtMost(len)
        val payloadLen = (len - payloadOff).coerceAtLeast(0)
        val app = classifyApp("TCP", sp, dp, d, payloadOff, len)
        val decoded = decodeApplication(app, d, payloadOff, len, sp, dp)
        val info = buildString {
            append("$ipNote • TCP $flags seq=$seq ack=$ack win=$window payload=$payloadLen")
            if (decoded.first.isNotBlank()) append(" • ${decoded.first}")
        }
        return PacketRecord(
            time = System.currentTimeMillis(), version = version, protocol = "TCP", appProtocol = app,
            source = src, destination = dst, sourcePort = sp, destinationPort = dp, length = len,
            ttlOrHop = ttl, tcpFlags = flags, info = info, dnsName = decoded.second,
            payloadPreview = textPreview(d, payloadOff, len), hexPreview = hex(d, payloadOff, len)
        )
    }

    private fun parseUdp(d: ByteArray, len: Int, version: Int, off: Int, src: String, dst: String, ttl: Int, ipNote: String): PacketRecord {
        if (len < off + 8) return PacketRecord(System.currentTimeMillis(), version, "UDP", source = src, destination = dst, sourcePort = null, destinationPort = null, length = len, ttlOrHop = ttl, info = "$ipNote • truncated UDP")
        val sp = u16(d, off)
        val dp = u16(d, off + 2)
        val udpLen = u16(d, off + 4)
        val payloadOff = off + 8
        val app = classifyApp("UDP", sp, dp, d, payloadOff, len)
        val decoded = decodeApplication(app, d, payloadOff, len, sp, dp)
        val info = buildString {
            append("$ipNote • UDP len=$udpLen payload=${(len - payloadOff).coerceAtLeast(0)}")
            if (decoded.first.isNotBlank()) append(" • ${decoded.first}")
        }
        return PacketRecord(
            time = System.currentTimeMillis(), version = version, protocol = "UDP", appProtocol = app,
            source = src, destination = dst, sourcePort = sp, destinationPort = dp, length = len,
            ttlOrHop = ttl, info = info, dnsName = decoded.second,
            payloadPreview = textPreview(d, payloadOff, len), hexPreview = hex(d, payloadOff, len)
        )
    }

    private fun parseIcmp(d: ByteArray, len: Int, version: Int, proto: Int, off: Int, src: String, dst: String, ttl: Int, ipNote: String): PacketRecord {
        val name = if (proto == 58) "ICMPv6" else "ICMP"
        val type = if (len > off) u8(d, off) else -1
        val code = if (len > off + 1) u8(d, off + 1) else -1
        val label = icmpLabel(proto, type, code)
        return PacketRecord(
            time = System.currentTimeMillis(), version = version, protocol = name, appProtocol = name,
            source = src, destination = dst, sourcePort = null, destinationPort = null, length = len,
            ttlOrHop = ttl, info = "$ipNote • $label (type=$type code=$code)", hexPreview = hex(d, off, len)
        )
    }

    private fun classifyApp(transport: String, sp: Int, dp: Int, d: ByteArray, payloadOff: Int, len: Int): String {
        val ports = setOf(sp, dp)
        if (53 in ports) return "DNS"
        if (5353 in ports) return "mDNS"
        if (67 in ports || 68 in ports) return "DHCP"
        if (1900 in ports) return "SSDP"
        if (123 in ports) return "NTP"
        if (22 in ports) return "SSH"
        if (25 in ports || 587 in ports) return "SMTP"
        if (110 in ports) return "POP3"
        if (143 in ports) return "IMAP"
        if (389 in ports) return "LDAP"
        if (636 in ports) return "LDAPS"
        if (445 in ports) return "SMB"
        if (3389 in ports) return "RDP"
        if (1883 in ports || 8883 in ports) return "MQTT"
        if (9100 in ports) return "RAW-PRINT"
        if (transport == "UDP" && 443 in ports) return "QUIC"
        if (transport == "TCP" && 443 in ports) return "TLS"
        if (ports.any { it in setOf(80, 8080, 8000, 8008, 8888, 5000, 3000) }) return "HTTP"
        if (payloadOff < len) {
            val p = textPreview(d, payloadOff, len).uppercase()
            if (p.startsWith("GET ") || p.startsWith("POST ") || p.startsWith("PUT ") || p.startsWith("HEAD ") || p.startsWith("HTTP/")) return "HTTP"
            if (p.startsWith("SSH-")) return "SSH"
        }
        return transport
    }

    private fun decodeApplication(app: String, d: ByteArray, off: Int, len: Int, sp: Int, dp: Int): Pair<String, String> {
        if (off >= len) return "" to ""
        return when (app) {
            "DNS", "mDNS" -> decodeDns(d, off, len)
            "HTTP" -> decodeHttp(d, off, len) to ""
            "TLS" -> {
                val sni = parseTlsSni(d, off, len)
                (if (sni.isNotBlank()) "TLS ClientHello SNI=$sni" else "TLS encrypted payload") to sni
            }
            "QUIC" -> "QUIC/HTTP3 candidate on UDP/443" to ""
            "DHCP" -> "DHCP ${if (sp == 68 || dp == 67) "client→server" else "server→client"}" to ""
            "SSDP" -> textPreview(d, off, min(len, off + 220)).lineSequence().firstOrNull().orEmpty() to ""
            "SSH" -> textPreview(d, off, min(len, off + 160)).lineSequence().firstOrNull().orEmpty() to ""
            else -> "" to ""
        }
    }

    private fun decodeDns(d: ByteArray, off: Int, len: Int): Pair<String, String> {
        if (len < off + 12) return "DNS truncated" to ""
        val id = u16(d, off)
        val flags = u16(d, off + 2)
        val qr = flags and 0x8000 != 0
        val qd = u16(d, off + 4)
        if (qd < 1) return "DNS ${if (qr) "response" else "query"} id=$id" to ""
        var p = off + 12
        val labels = mutableListOf<String>()
        var guard = 0
        while (p < len && guard++ < 64) {
            val n = u8(d, p); p++
            if (n == 0) break
            if (n and 0xC0 == 0xC0) { p++; break }
            if (n > 63 || p + n > len) break
            labels += d.copyOfRange(p, p + n).toString(Charsets.UTF_8)
            p += n
        }
        val name = labels.joinToString(".")
        val qtype = if (p + 1 < len) u16(d, p) else -1
        val typeName = when (qtype) { 1 -> "A"; 28 -> "AAAA"; 5 -> "CNAME"; 12 -> "PTR"; 15 -> "MX"; 16 -> "TXT"; 33 -> "SRV"; 65 -> "HTTPS"; else -> if (qtype > 0) "TYPE$qtype" else "?" }
        return "DNS ${if (qr) "response" else "query"} $typeName ${name.ifBlank { "<compressed>" }}" to name
    }

    private fun decodeHttp(d: ByteArray, off: Int, len: Int): String {
        val text = textPreview(d, off, min(len, off + 900))
        if (text.isBlank()) return "HTTP payload"
        val lines = text.lines()
        val first = lines.firstOrNull()?.trim().orEmpty()
        val host = lines.firstOrNull { it.startsWith("Host:", true) }?.substringAfter(':')?.trim().orEmpty()
        return buildString {
            append(first.take(180))
            if (host.isNotBlank()) append(" Host=$host")
        }
    }

    private fun parseTlsSni(d: ByteArray, off: Int, len: Int): String {
        try {
            if (len < off + 5 || u8(d, off) != 22) return ""
            val recordLen = u16(d, off + 3)
            val recordEnd = min(len, off + 5 + recordLen)
            var p = off + 5
            if (p + 4 > recordEnd || u8(d, p) != 1) return ""
            p += 4
            if (p + 34 > recordEnd) return ""
            p += 34
            val sessionLen = u8(d, p); p += 1 + sessionLen
            if (p + 2 > recordEnd) return ""
            val cipherLen = u16(d, p); p += 2 + cipherLen
            if (p >= recordEnd) return ""
            val compLen = u8(d, p); p += 1 + compLen
            if (p + 2 > recordEnd) return ""
            val extLen = u16(d, p); p += 2
            val extEnd = min(recordEnd, p + extLen)
            while (p + 4 <= extEnd) {
                val type = u16(d, p)
                val l = u16(d, p + 2)
                p += 4
                if (p + l > extEnd) break
                if (type == 0 && l >= 5) {
                    var q = p + 2
                    val listEnd = min(p + l, q + u16(d, p))
                    while (q + 3 <= listEnd) {
                        val nameType = u8(d, q)
                        val nameLen = u16(d, q + 1)
                        q += 3
                        if (q + nameLen > listEnd) break
                        if (nameType == 0) return d.copyOfRange(q, q + nameLen).toString(Charsets.US_ASCII)
                        q += nameLen
                    }
                }
                p += l
            }
        } catch (_: Exception) {}
        return ""
    }

    private fun tcpFlags(v: Int): String {
        val out = mutableListOf<String>()
        if (v and 0x80 != 0) out += "CWR"
        if (v and 0x40 != 0) out += "ECE"
        if (v and 0x20 != 0) out += "URG"
        if (v and 0x10 != 0) out += "ACK"
        if (v and 0x08 != 0) out += "PSH"
        if (v and 0x04 != 0) out += "RST"
        if (v and 0x02 != 0) out += "SYN"
        if (v and 0x01 != 0) out += "FIN"
        return out.joinToString(",").ifBlank { "NONE" }
    }

    private fun icmpLabel(proto: Int, type: Int, code: Int): String {
        return if (proto == 1) when (type) {
            0 -> "Echo reply"
            3 -> "Destination unreachable code=$code"
            8 -> "Echo request"
            11 -> "Time exceeded"
            else -> "ICMP"
        } else when (type) {
            128 -> "Echo request"
            129 -> "Echo reply"
            1 -> "Destination unreachable"
            2 -> "Packet too big"
            3 -> "Time exceeded"
            135 -> "Neighbor solicitation"
            136 -> "Neighbor advertisement"
            else -> "ICMPv6"
        }
    }

    private fun textPreview(d: ByteArray, off: Int, len: Int): String {
        if (off >= len) return ""
        val end = min(len, off + 512)
        val chars = StringBuilder()
        for (i in off until end) {
            val b = u8(d, i)
            chars.append(if (b == 9 || b == 10 || b == 13 || b in 32..126) b.toChar() else '.')
        }
        return chars.toString().trim().take(512)
    }

    private fun hex(d: ByteArray, off: Int, len: Int): String {
        if (off >= len) return ""
        val end = min(len, off + 96)
        return (off until end).joinToString(" ") { "%02X".format(u8(d, it)) }
    }

    private fun u8(d: ByteArray, i: Int): Int = if (i in d.indices) d[i].toInt() and 0xff else 0
    private fun u16(d: ByteArray, i: Int): Int = (u8(d, i) shl 8) or u8(d, i + 1)
    private fun u32(d: ByteArray, i: Int): Long = ((u8(d, i).toLong() shl 24) or (u8(d, i + 1).toLong() shl 16) or (u8(d, i + 2).toLong() shl 8) or u8(d, i + 3).toLong()) and 0xffffffffL

    private fun stopCapture() {
        running = false
        AppState.vpnCaptureRunning = false
        AppState.changed()
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    private fun createChannel() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Saphaea capture", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(): Notification {
        val stopIntent = Intent(this, CaptureVpnService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 2, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Saphaea Inspector capture")
            .setContentText("Deep packet metadata decoding is active")
            .setOngoing(true)
            .addAction(0, "Stop", stopPending)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    companion object {
        const val ACTION_STOP = "com.saphaea.inspector.mobile.STOP_CAPTURE"
        private const val CHANNEL_ID = "saphaea_capture"
        private const val NOTIFICATION_ID = 7701
    }
}
