package com.saphaea.inspector.mobile

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.net.TrafficStats
import android.net.VpnService
import android.os.*
import android.security.KeyChain
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Base64
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var engine: NetworkEngine
    private lateinit var proxy: ProxyEngine
    private lateinit var mainContent: LinearLayout
    private lateinit var navBar: LinearLayout
    private val navButtons = linkedMapOf<String, Button>()
    private var currentPage = "OVERVIEW"
    private var currentNetworkPage = "DISCOVERY"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var stateDirty = true

    private var overviewMetrics: LinearLayout? = null
    private var discoveryList: LinearLayout? = null
    private var discoveryStatus: TextView? = null
    private var wifiList: LinearLayout? = null
    private var wifiStatus: TextView? = null
    private var topologyView: TopologyView? = null
    private var captureList: LinearLayout? = null
    private var captureStatus: TextView? = null
    private var proxyList: LinearLayout? = null
    private var proxyStatus: TextView? = null
    private var analyzeRoot: LinearLayout? = null
    private var monitorChart: TrafficChartView? = null
    private var monitorRx: TextView? = null
    private var monitorTx: TextView? = null
    private var monitorTotals: TextView? = null
    private var lastRx = TrafficStats.getTotalRxBytes().coerceAtLeast(0)
    private var lastTx = TrafficStats.getTotalTxBytes().coerceAtLeast(0)

    private var repeaterMethod: Spinner? = null
    private var repeaterUrl: EditText? = null
    private var repeaterHeaders: EditText? = null
    private var repeaterBody: EditText? = null
    private var repeaterOutput: EditText? = null

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        stateDirty = true
        if (currentPage == "NETWORK" && currentNetworkPage == "WIFI") showPage("NETWORK")
    }
    private val vpnLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) startVpnService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BLACK
        window.navigationBarColor = Ui.BLACK
        engine = NetworkEngine(this)
        proxy = ProxyEngine(this)
        buildShell()
        AppState.onStateChanged = { stateDirty = true }
        showPage("OVERVIEW")
        handler.post(dynamicTick)
    }

    override fun onDestroy() {
        AppState.onStateChanged = null
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        super.onDestroy()
    }

    private val dynamicTick = object : Runnable {
        override fun run() {
            if (stateDirty) {
                stateDirty = false
                refreshDynamic()
            }
            updateTrafficMonitor()
            handler.postDelayed(this, 750)
        }
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BLACK)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 9), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 9))
            background = Ui.rounded(Ui.BLACK, 0f)
        }
        val brandBox = TextView(this).apply {
            text = "S"
            gravity = Gravity.CENTER
            textSize = 19f
            setTextColor(Ui.BLACK)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            background = Ui.rounded(Ui.WHITE, Ui.dp(this@MainActivity, 10).toFloat())
        }
        header.addView(brandBox, LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 42)))
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@MainActivity, 10), 0, 0, 0)
            addView(Ui.text(this@MainActivity, "SAPHAEA", 15f, Ui.WHITE, true))
            addView(Ui.text(this@MainActivity, "INSPECTOR MOBILE", 9f, Ui.MUTED, true))
        }
        header.addView(brand, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Ui.text(this, "0.2 ALPHA", 10f, Ui.MUTED, true))
        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val navScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; setBackgroundColor(Ui.BLACK) }
        navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 5), Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 10))
        }
        listOf("OVERVIEW", "NETWORK", "CAPTURE", "PROXY", "REPEATER", "ANALYZE", "CODEC", "GUIDE", "SETTINGS").forEach { page ->
            val b = Ui.whiteButton(this, page) { showPage(page) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(this, 46)).apply { marginEnd = Ui.dp(this@MainActivity, 8) }
            navBar.addView(b, lp)
            navButtons[page] = b
        }
        navScroll.addView(navBar)
        root.addView(navScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(Ui.BLACK) }
        mainContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 40))
        }
        scroll.addView(mainContent, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun showPage(page: String) {
        currentPage = page
        navButtons.forEach { (name, b) ->
            b.setTextColor(Ui.BLACK)
            b.background = Ui.rounded(if (name == page) 0xFFDDE7FF.toInt() else Ui.WHITE, Ui.dp(this, 12).toFloat(), if (name == page) 0xFF8DA4CB.toInt() else 0xFFD5D5D5.toInt())
        }
        mainContent.removeAllViews()
        when (page) {
            "OVERVIEW" -> buildOverview()
            "NETWORK" -> buildNetwork()
            "CAPTURE" -> buildCapture()
            "PROXY" -> buildProxy()
            "REPEATER" -> buildRepeater()
            "ANALYZE" -> buildAnalyze()
            "CODEC" -> buildCodec()
            "GUIDE" -> buildGuide()
            "SETTINGS" -> buildSettings()
        }
        stateDirty = true
    }

    private fun pageIntro(eyebrow: String, title: String, body: String) {
        mainContent.addView(Ui.text(this, eyebrow.uppercase(), 11f, Ui.MUTED, true))
        Ui.addGap(mainContent, this, 6)
        mainContent.addView(Ui.title(this, title))
        Ui.addGap(mainContent, this, 5)
        mainContent.addView(Ui.subtitle(this, body))
        Ui.addGap(mainContent, this, 16)
    }

    private fun buildOverview() {
        pageIntro("Saphaea Inspector", "See the network beneath the app", "A mobile network, packet, web-debugging and diagnostics workstation built for authorized testing and troubleshooting.")
        overviewMetrics = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mainContent.addView(overviewMetrics)
        Ui.addGap(mainContent, this, 14)
        val quick = Ui.card(this)
        quick.addView(Ui.text(this, "QUICK START", 10f, Ui.MUTED, true))
        Ui.addGap(quick, this, 6)
        quick.addView(Ui.text(this, "Start with visibility", 20f, Ui.WHITE, true))
        Ui.addGap(quick, this, 6)
        quick.addView(Ui.subtitle(this, "Scan the local LAN, inspect nearby Wi-Fi, watch throughput, capture Android packet metadata, or point a browser at the local proxy."))
        Ui.addGap(quick, this, 12)
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(Ui.whiteButton(this, "SCAN LAN") { currentNetworkPage = "DISCOVERY"; showPage("NETWORK") }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f).apply { marginEnd = Ui.dp(this@MainActivity, 8) })
        r1.addView(Ui.whiteButton(this, "SCAN WI-FI") { currentNetworkPage = "WIFI"; showPage("NETWORK") }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f))
        quick.addView(r1)
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r2.setPadding(0, Ui.dp(this, 8), 0, 0)
        r2.addView(Ui.whiteButton(this, "CAPTURE") { showPage("CAPTURE") }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f).apply { marginEnd = Ui.dp(this@MainActivity, 8) })
        r2.addView(Ui.whiteButton(this, "OPEN PROXY") { showPage("PROXY") }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f))
        quick.addView(r2)
        mainContent.addView(quick)
        Ui.addGap(mainContent, this, 12)
        mainContent.addView(Ui.sectionHeader(this, "MOBILE MODEL", "Android-native rather than a desktop port", "LAN/Wi-Fi discovery uses Android networking APIs. Packet metadata capture uses Android's user-approved VPN interface. The proxy binds to loopback and HTTPS inspection requires an explicitly installed Saphaea CA."))
        renderOverviewMetrics()
    }

    private fun renderOverviewMetrics() {
        val root = overviewMetrics ?: return
        root.removeAllViews()
        val rows = listOf(
            Triple("DEVICES", AppState.devices.size.toString(), "LAN devices discovered"),
            Triple("WI-FI", AppState.wifi.size.toString(), "Nearby access points"),
            Triple("PACKETS", AppState.packets.size.toString(), if (AppState.vpnCaptureRunning) "Capture active" else "Capture idle"),
            Triple("WEB SESSIONS", AppState.proxySessions.size.toString(), if (AppState.proxyRunning) "Proxy 127.0.0.1:${AppState.proxyPort}" else "Proxy stopped")
        )
        rows.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, m ->
                row.addView(Ui.metricCard(this, m.first, m.second, m.third), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i == 0 && pair.size > 1) marginEnd = Ui.dp(this@MainActivity, 8) })
            }
            root.addView(row)
            root.addView(Space(this), LinearLayout.LayoutParams(1, Ui.dp(this, 8)))
        }
    }

    private fun buildNetwork() {
        pageIntro("Network", "Discover, map and monitor", "Find devices, IPs, names, MAC neighbors, services and nearby Wi-Fi, then turn those observations into a live topology and diagnostics workflow.")
        val barScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("DISCOVERY", "WIFI", "TOPOLOGY", "MONITOR", "UTILITIES").forEach { sub ->
            val b = Ui.whiteButton(this, sub) { currentNetworkPage = sub; showPage("NETWORK") }
            if (sub == currentNetworkPage) b.background = Ui.rounded(0xFFDDE7FF.toInt(), Ui.dp(this, 12).toFloat(), 0xFF8DA4CB.toInt())
            bar.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(this, 46)).apply { marginEnd = Ui.dp(this@MainActivity, 7) })
        }
        barScroll.addView(bar)
        mainContent.addView(barScroll)
        Ui.addGap(mainContent, this, 12)
        when (currentNetworkPage) {
            "DISCOVERY" -> buildDiscovery()
            "WIFI" -> buildWifi()
            "TOPOLOGY" -> buildTopology()
            "MONITOR" -> buildMonitor()
            "UTILITIES" -> buildUtilities()
        }
    }

    private fun buildDiscovery() {
        val info = engine.getLocalInfo()
        val infoCard = Ui.card(this)
        infoCard.addView(Ui.text(this, "LOCAL NETWORK", 10f, Ui.MUTED, true))
        Ui.addGap(infoCard, this, 6)
        infoCard.addView(Ui.text(this, "${info.transport} • ${info.interfaceName.ifBlank { "interface" }}", 18f, Ui.WHITE, true))
        infoCard.addView(Ui.subtitle(this, "IP ${info.ip.ifBlank { "unavailable" }}  •  Gateway ${info.gateway.ifBlank { "unavailable" }}\nDNS ${info.dns.joinToString(", ").ifBlank { "unavailable" }}"))
        mainContent.addView(infoCard)
        Ui.addGap(mainContent, this, 10)
        val controls = Ui.card(this)
        val cidr = Ui.input(this, "CIDR", engine.suggestedCidr())
        controls.addView(Ui.text(this, "SCAN RANGE", 10f, Ui.MUTED, true))
        Ui.addGap(controls, this, 6); controls.addView(cidr)
        Ui.addGap(controls, this, 8)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Ui.whiteButton(this, "FAST SCAN") { runLanScan(cidr.text.toString(), false) }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f).apply { marginEnd = Ui.dp(this@MainActivity, 8) })
        buttons.addView(Ui.whiteButton(this, "DEEP SCAN") { runLanScan(cidr.text.toString(), true) }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f))
        controls.addView(buttons)
        discoveryStatus = Ui.subtitle(this, "Fast scan identifies reachable hosts. Deep scan additionally checks common service ports on discovered devices.")
        Ui.addGap(controls, this, 8); controls.addView(discoveryStatus)
        mainContent.addView(controls)
        Ui.addGap(mainContent, this, 12)
        discoveryList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mainContent.addView(discoveryList)
        renderDevices()
    }

    private fun runLanScan(cidr: String, deep: Boolean) {
        discoveryStatus?.text = "Scanning $cidr…"
        engine.scanLan(cidr, deep, { done, total ->
            discoveryStatus?.text = "Scanning $cidr  •  $done / $total"
        }) { result ->
            discoveryStatus?.text = "Scan complete • ${result.size} device(s) found${if (deep) " • service discovery enabled" else ""}."
            renderDevices(); stateDirty = true
        }
    }

    private fun renderDevices() {
        val root = discoveryList ?: return
        root.removeAllViews()
        if (AppState.devices.isEmpty()) {
            root.addView(Ui.sectionHeader(this, "DISCOVERY", "No devices yet", "Run a LAN scan. Deep Scan now combines reachability, common-service probes, banners, HTTP fingerprints, SSDP/UPnP advertisements and Android neighbor-table identifiers."))
            return
        }
        AppState.devices.forEach { d ->
            val c = Ui.card(this, 13)
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(Ui.text(this, d.ip, 17f, Ui.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val badge = when { d.isLocal -> "THIS DEVICE"; d.isGateway -> "GATEWAY"; else -> d.role.uppercase() }
            top.addView(Ui.text(this, badge, 10f, Ui.MUTED, true))
            c.addView(top)
            Ui.addGap(c, this, 5)
            val identity = buildString {
                append("Name: ${d.host.ifBlank { "—" }}")
                append("\nMAC: ${d.mac.ifBlank { "— / restricted" }}")
                if (d.vendor.isNotBlank()) append("\nVendor hint: ${d.vendor}")
                if (d.osHint.isNotBlank()) append("\nPlatform hint: ${d.osHint}")
                append("\nLatency: ${if (d.latencyMs >= 0) "${d.latencyMs} ms" else "—"}")
                if (d.services.isNotBlank()) append("\nServices: ${d.services}")
                if (d.webTitle.isNotBlank()) append("\nWeb: ${d.webTitle}")
                if (d.exposure.isNotBlank()) append("\nExposure: ${d.exposure}")
            }
            c.addView(Ui.subtitle(this, identity))
            if (d.serviceDetails.isNotBlank()) {
                Ui.addGap(c, this, 7)
                c.addView(Ui.monoBox(this, d.serviceDetails).apply { isFocusable = false; minLines = 2; maxLines = 6 })
            }
            Ui.addGap(c, this, 8)
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(Ui.whiteButton(this, "DEVICE REPORT") { showDeviceReport(d) }, LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f).apply { marginEnd = Ui.dp(this@MainActivity, 8) })
            actions.addView(Ui.whiteButton(this, "QUICK HTTP") {
                val url = guessDeviceUrl(d)
                pendingRepeater = ProxySession(method = "GET", url = url, status = 0, type = "DEVICE QUICK REQUEST", requestHeaders = "User-Agent: Saphaea-Inspector-Mobile/0.2\nAccept: */*")
                showPage("REPEATER")
            }, LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f))
            c.addView(actions)
            root.addView(c)
            root.addView(Space(this), LinearLayout.LayoutParams(1, Ui.dp(this, 8)))
        }
    }

    private fun guessDeviceUrl(d: NetworkDevice): String {
        return when {
            d.services.contains("8443/HTTPS", true) -> "https://${d.ip}:8443/"
            d.services.contains("443/HTTPS", true) -> "https://${d.ip}/"
            d.services.contains("8080/HTTP", true) -> "http://${d.ip}:8080/"
            d.services.contains("8000/HTTP", true) -> "http://${d.ip}:8000/"
            d.services.contains("8888/HTTP", true) -> "http://${d.ip}:8888/"
            d.services.contains("3000/HTTP", true) -> "http://${d.ip}:3000/"
            d.services.contains("5000/HTTP", true) -> "http://${d.ip}:5000/"
            else -> "http://${d.ip}/"
        }
    }

    private fun showDeviceReport(d: NetworkDevice) {
        val report = buildString {
            appendLine("IP: ${d.ip}")
            appendLine("Name: ${d.host.ifBlank { "unknown" }}")
            appendLine("MAC: ${d.mac.ifBlank { "restricted / unavailable" }}")
            appendLine("Vendor hint: ${d.vendor.ifBlank { "unknown" }}")
            appendLine("Role: ${d.role}")
            appendLine("Platform hint: ${d.osHint.ifBlank { "unknown" }}")
            appendLine("Latency: ${if (d.latencyMs >= 0) "${d.latencyMs} ms" else "unknown"}")
            appendLine("Services: ${d.services.ifBlank { "none detected" }}")
            appendLine("Exposure: ${d.exposure.ifBlank { "not classified" }}")
            if (d.webTitle.isNotBlank()) appendLine("Web fingerprint: ${d.webTitle}")
            if (d.serviceDetails.isNotBlank()) { appendLine(); appendLine("SERVICE FINGERPRINTS"); append(d.serviceDetails) }
        }
        AlertDialog.Builder(this).setTitle("Device analysis").setMessage(report).setPositiveButton("Close", null).show()
    }

    private fun buildWifi() {
        val card = Ui.card(this)
        card.addView(Ui.text(this, "WI-FI VISIBILITY", 10f, Ui.MUTED, true))
        Ui.addGap(card, this, 5)
        card.addView(Ui.text(this, "Nearby access points", 20f, Ui.WHITE, true))
        Ui.addGap(card, this, 5)
        card.addView(Ui.subtitle(this, "SSID, BSSID, signal, channel, frequency and advertised security capabilities. Android may require Location services to be enabled even after permission is granted."))
        Ui.addGap(card, this, 10)
        card.addView(Ui.whiteButton(this, "SCAN WI-FI") { ensureWifiPermissionsAndScan() })
        wifiStatus = Ui.subtitle(this, engine.connectedWifiSummary())
        Ui.addGap(card, this, 9); card.addView(wifiStatus)
        mainContent.addView(card)
        Ui.addGap(mainContent, this, 12)
        wifiList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mainContent.addView(wifiList)
        renderWifi()
    }

    private fun ensureWifiPermissionsAndScan() {
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.NEARBY_WIFI_DEVICES
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { permissionLauncher.launch(missing.toTypedArray()); return }
        wifiStatus?.text = "Scanning nearby Wi-Fi…"
        engine.scanWifi { list, error ->
            wifiStatus?.text = error ?: "Scan complete • ${list.size} access point(s).\n${engine.connectedWifiSummary()}"
            renderWifi(); stateDirty = true
        }
    }

    private fun renderWifi() {
        val root = wifiList ?: return
        root.removeAllViews()
        if (AppState.wifi.isEmpty()) {
            root.addView(Ui.sectionHeader(this, "WI-FI", "No scan results", "Grant the requested Wi-Fi/Location permission, make sure Location services are enabled, and run Scan Wi-Fi.")); return
        }
        AppState.wifi.forEach { w ->
            val c = Ui.card(this, 13)
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            top.addView(Ui.text(this, w.ssid, 17f, Ui.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(Ui.text(this, "${w.level}%", 15f, Ui.WHITE, true))
            c.addView(top)
            Ui.addGap(c, this, 5)
            c.addView(Ui.subtitle(this, "BSSID ${w.bssid}\nChannel ${w.channel} • ${w.frequency} MHz\n${w.capabilities}"))
            root.addView(c); root.addView(Space(this), LinearLayout.LayoutParams(1, Ui.dp(this, 8)))
        }
    }

    private fun buildTopology() {
        mainContent.addView(Ui.sectionHeader(this, "TOPOLOGY", "Visual network map", "The gateway is centered and discovered devices radiate outward. Run Discovery first; deeper topology inference will expand in later releases."))
        Ui.addGap(mainContent, this, 10)
        topologyView = TopologyView(this).apply { devices = AppState.devices.toList(); background = Ui.rounded(Ui.PANEL, Ui.dp(this@MainActivity, 14).toFloat(), Ui.LINE) }
        mainContent.addView(topologyView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 520)))
    }

    private fun buildMonitor() {
        val info = engine.getLocalInfo()
        mainContent.addView(Ui.sectionHeader(this, "MONITOR", "Live device throughput", "Watch aggregate Android network I/O without rebuilding the interface. White is receive traffic; gray is transmit traffic."))
        Ui.addGap(mainContent, this, 10)
        val metrics = Ui.card(this)
        monitorRx = Ui.text(this, "RX 0 B/s", 20f, Ui.WHITE, true)
        monitorTx = Ui.text(this, "TX 0 B/s", 20f, Ui.WHITE, true)
        monitorTotals = Ui.subtitle(this, "${info.transport} • ${info.interfaceName}")
        metrics.addView(monitorRx); Ui.addGap(metrics, this, 4); metrics.addView(monitorTx); Ui.addGap(metrics, this, 6); metrics.addView(monitorTotals)
        mainContent.addView(metrics)
        Ui.addGap(mainContent, this, 10)
        monitorChart = TrafficChartView(this).apply { background = Ui.rounded(Ui.PANEL, Ui.dp(this@MainActivity, 14).toFloat(), Ui.LINE) }
        mainContent.addView(monitorChart)
    }

    private fun updateTrafficMonitor() {
        if (currentPage != "NETWORK" || currentNetworkPage != "MONITOR") return
        val rx = TrafficStats.getTotalRxBytes().coerceAtLeast(0)
        val tx = TrafficStats.getTotalTxBytes().coerceAtLeast(0)
        val drx = max(0, rx - lastRx)
        val dtx = max(0, tx - lastTx)
        lastRx = rx; lastTx = tx
        monitorRx?.text = "RX ${formatBytes(drx)}/s"
        monitorTx?.text = "TX ${formatBytes(dtx)}/s"
        monitorTotals?.text = "Total received ${formatBytes(rx)}  •  sent ${formatBytes(tx)}"
        monitorChart?.add(drx, dtx)
    }

    private fun buildUtilities() {
        mainContent.addView(Ui.sectionHeader(this, "UTILITIES", "Common network tools in one place", "Ping, DNS/reverse lookup, TCP port checks, route diagnostics, neighbor table, routes and interface information."))
        Ui.addGap(mainContent, this, 10)
        val box = Ui.card(this)
        val target = Ui.input(this, "Target host or IP", engine.getLocalInfo().gateway.ifBlank { "1.1.1.1" })
        val ports = Ui.input(this, "Ports", "22,53,80,443,445,3389,8080")
        val output = Ui.monoBox(this, "Choose a utility.")
        box.addView(target); Ui.addGap(box, this, 7); box.addView(ports); Ui.addGap(box, this, 9)
        val buttons = listOf(
            "PING" to { engine.ping(target.text.toString()) },
            "DNS" to { engine.dns(target.text.toString()) },
            "TCP PORTS" to { engine.tcpCheck(target.text.toString(), ports.text.toString()) },
            "TRACE" to { engine.trace(target.text.toString()) },
            "NEIGHBORS" to { engine.neighbors() },
            "ROUTES" to { engine.routes() },
            "INTERFACES" to { engine.interfaces() }
        )
        buttons.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, item ->
                row.addView(Ui.whiteButton(this, item.first) { runUtility(output, item.second) }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f).apply { if (i == 0 && pair.size > 1) marginEnd = Ui.dp(this@MainActivity, 8) })
            }
            box.addView(row); Ui.addGap(box, this, 7)
        }
        box.addView(output, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 330)))
        mainContent.addView(box)
    }

    private fun runUtility(output: EditText, fn: () -> String) {
        output.setText("Working…")
        scope.launch {
            val text = withContext(Dispatchers.IO) { fn() }
            output.setText(text)
        }
    }

    private fun buildCapture() {
        pageIntro("Capture", "Decode packets, not just rows", "Inspect IPv4/IPv6, TCP flags, UDP, ICMP, DNS/mDNS questions, HTTP request lines/hosts, TLS SNI, QUIC candidates and common application protocols from Android's user-approved VPN interface.")
        val warning = Ui.card(this)
        warning.addView(Ui.text(this, "IMPORTANT", 10f, 0xFFFFD7A8.toInt(), true))
        Ui.addGap(warning, this, 5)
        warning.addView(Ui.subtitle(this, "Raw VPN Capture is still a short diagnostic mode in this alpha. Packet forwarding is not implemented yet, so normal network traffic can pause while capture is active. v0.2 substantially improves decoding of the packets Saphaea receives."))
        Ui.addGap(warning, this, 10)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.whiteButton(this, "START RAW CAPTURE") { requestVpnCapture() }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f).apply { marginEnd = Ui.dp(this@MainActivity, 8) })
        row.addView(Ui.whiteButton(this, "STOP") { stopVpnCapture() }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f))
        warning.addView(row)
        captureStatus = Ui.subtitle(this, captureStatusText())
        Ui.addGap(warning, this, 8); warning.addView(captureStatus)
        mainContent.addView(warning)
        Ui.addGap(mainContent, this, 10)
        val search = Ui.input(this, "Filter: dns, tls, http, app:quic, port:443, flags:syn, src:…")
        search.setOnEditorActionListener { _, _, _ -> renderPackets(search.text.toString()); false }
        mainContent.addView(search)
        Ui.addGap(mainContent, this, 7)
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("DNS", "HTTP", "TLS", "TCP").forEachIndexed { i, label ->
            quick.addView(Ui.whiteButton(this, label) { search.setText(label.lowercase()); renderPackets(label.lowercase()) }, LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f).apply { if (i < 3) marginEnd = Ui.dp(this@MainActivity, 5) })
        }
        mainContent.addView(quick)
        Ui.addGap(mainContent, this, 10)
        captureList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = search }
        mainContent.addView(captureList)
        renderPackets("")
    }

    private fun requestVpnCapture() {
        AlertDialog.Builder(this)
            .setTitle("Start raw VPN capture?")
            .setMessage("Saphaea v0.2 will decode packet metadata but does not forward captured traffic yet. Your normal network traffic can pause while capture is active. Stop capture when finished.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue") { _, _ ->
                val prep = VpnService.prepare(this)
                if (prep != null) vpnLauncher.launch(prep) else startVpnService()
            }.show()
    }

    private fun startVpnService() {
        val intent = Intent(this, CaptureVpnService::class.java)
        ContextCompat.startForegroundService(this, intent)
        captureStatus?.text = "Starting Android VPN capture…"
    }

    private fun stopVpnCapture() {
        startService(Intent(this, CaptureVpnService::class.java).setAction(CaptureVpnService.ACTION_STOP))
        captureStatus?.text = "Capture stopping…"
    }

    private fun captureStatusText() = if (AppState.vpnCaptureRunning) "RAW CAPTURE ACTIVE • ${AppState.packets.size} packet records" else "Capture idle • ${AppState.packets.size} records retained"

    private fun renderPackets(filter: String? = null) {
        val root = captureList ?: return
        root.removeAllViews()
        captureStatus?.text = captureStatusText()
        val f = filter?.trim()?.lowercase().orEmpty()
        val list = AppState.packets.asSequence().filter { p ->
            val searchable = "${p.protocol} ${p.appProtocol} ${p.source} ${p.destination} ${p.sourcePort} ${p.destinationPort} ${p.tcpFlags} ${p.info} ${p.dnsName}".lowercase()
            when {
                f.isBlank() -> true
                f in setOf("tcp", "udp", "icmp", "icmpv6") -> p.protocol.lowercase().startsWith(f)
                f in setOf("dns", "mdns", "http", "tls", "quic", "dhcp", "ssdp", "ssh", "smb", "rdp") -> p.appProtocol.lowercase() == f
                f.startsWith("app:") -> p.appProtocol.lowercase().contains(f.substringAfter(':'))
                f.startsWith("port:") -> f.substringAfter(':').toIntOrNull()?.let { p.sourcePort == it || p.destinationPort == it } ?: true
                f.startsWith("src:") -> p.source.contains(f.substringAfter(':'))
                f.startsWith("dst:") -> p.destination.contains(f.substringAfter(':'))
                f.startsWith("host:") -> p.info.lowercase().contains(f.substringAfter(':')) || p.dnsName.lowercase().contains(f.substringAfter(':'))
                f.startsWith("flags:") -> p.tcpFlags.lowercase().contains(f.substringAfter(':'))
                else -> searchable.contains(f)
            }
        }.take(220).toList()
        if (list.isEmpty()) { root.addView(Ui.sectionHeader(this, "PACKETS", "No matching packets", "Start Raw Capture for a short diagnostic window, or change the display filter.")); return }
        list.forEach { p ->
            val c = Ui.card(this, 11)
            val app = p.appProtocol.takeIf { it.isNotBlank() && it != p.protocol }?.let { " / $it" }.orEmpty()
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(Ui.text(this, "${Ui.time(p.time)}   ${p.protocol}$app", 12f, Ui.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(Ui.text(this, "${p.length} B", 11f, Ui.MUTED, true))
            c.addView(top)
            Ui.addGap(c, this, 4)
            val src = if (p.sourcePort != null) "${p.source}:${p.sourcePort}" else p.source
            val dst = if (p.destinationPort != null) "${p.destination}:${p.destinationPort}" else p.destination
            c.addView(Ui.subtitle(this, "$src  →  $dst\n${p.info.ifBlank { "IPv${p.version} • hop ${p.ttlOrHop}" }}"))
            Ui.addGap(c, this, 7)
            c.addView(Ui.whiteButton(this, "PACKET DETAILS") { showPacketDetails(p) })
            root.addView(c); root.addView(Space(this), LinearLayout.LayoutParams(1, Ui.dp(this, 6)))
        }
    }

    private fun showPacketDetails(p: PacketRecord) {
        val detail = buildString {
            appendLine("Time: ${Ui.time(p.time)}")
            appendLine("IPv${p.version} • ${p.protocol}${if (p.appProtocol.isNotBlank()) " / ${p.appProtocol}" else ""}")
            appendLine("Source: ${p.source}${p.sourcePort?.let { ":$it" }.orEmpty()}")
            appendLine("Destination: ${p.destination}${p.destinationPort?.let { ":$it" }.orEmpty()}")
            appendLine("Length: ${p.length} bytes")
            appendLine("TTL / Hop: ${p.ttlOrHop}")
            if (p.tcpFlags.isNotBlank()) appendLine("TCP flags: ${p.tcpFlags}")
            if (p.dnsName.isNotBlank()) appendLine("Name / SNI: ${p.dnsName}")
            if (p.info.isNotBlank()) appendLine("Decode: ${p.info}")
            if (p.payloadPreview.isNotBlank()) { appendLine(); appendLine("PAYLOAD PREVIEW"); appendLine(p.payloadPreview) }
            if (p.hexPreview.isNotBlank()) { appendLine(); appendLine("HEX PREVIEW"); append(p.hexPreview) }
        }
        AlertDialog.Builder(this).setTitle("Packet decode").setMessage(detail).setPositiveButton("Close", null).show()
    }

    private fun buildProxy() {
        pageIntro("Proxy", "Web debugging on Android", "Run an explicit HTTP/HTTPS proxy on 127.0.0.1. CONNECT tunneling works without a CA. HTTPS inspection requires the Saphaea CA and only works for clients that trust user-installed certificates.")
        val controls = Ui.card(this)
        val port = Ui.input(this, "Proxy port", AppState.proxyPort.toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        val inspect = CheckBox(this).apply {
            text = "Enable explicit HTTPS inspection"
            setTextColor(Ui.WHITE)
            isChecked = proxy.inspectHttps
            buttonTintList = android.content.res.ColorStateList.valueOf(Ui.WHITE)
        }
        controls.addView(port); Ui.addGap(controls, this, 8); controls.addView(inspect)
        Ui.addGap(controls, this, 8)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.whiteButton(this, "START PROXY") {
            val p = port.text.toString().toIntOrNull()?.coerceIn(1024, 65535) ?: 8080
            if (inspect.isChecked && !proxy.ca.exists()) proxy.ca.ensure()
            val r = proxy.start(p, inspect.isChecked)
            proxyStatus?.text = r.fold({ "Proxy listening on 127.0.0.1:$p${if (inspect.isChecked) " • HTTPS inspection enabled" else ""}" }, { "Proxy error: ${it.message}" })
        }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f).apply { marginEnd = Ui.dp(this@MainActivity, 8) })
        row.addView(Ui.whiteButton(this, "STOP") { proxy.stop(); proxyStatus?.text = "Proxy stopped" }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f))
        controls.addView(row)
        Ui.addGap(controls, this, 8)
        val caRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        caRow.addView(Ui.whiteButton(this, "INSTALL SAPHAEA CA") { installCa() }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f).apply { marginEnd = Ui.dp(this@MainActivity, 8) })
        caRow.addView(Ui.whiteButton(this, "RESET LOCAL CA") { proxy.ca.remove(); proxyStatus?.text = "Local CA files reset. Remove any previously trusted Saphaea certificate separately in Android security settings." }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f))
        controls.addView(caRow)
        proxyStatus = Ui.subtitle(this, if (AppState.proxyRunning) "Proxy listening on 127.0.0.1:${AppState.proxyPort}" else "Proxy stopped • Local CA ${if (proxy.ca.exists()) "generated" else "not generated"}")
        Ui.addGap(controls, this, 8); controls.addView(proxyStatus)
        mainContent.addView(controls)
        Ui.addGap(mainContent, this, 12)
        proxyList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mainContent.addView(proxyList)
        renderProxySessions()
    }

    private fun installCa() {
        try {
            val bytes = proxy.ca.caBytes()
            val intent = KeyChain.createInstallIntent().apply {
                putExtra(KeyChain.EXTRA_CERTIFICATE, bytes)
                putExtra(KeyChain.EXTRA_NAME, "Saphaea Inspector Mobile Root CA")
            }
            startActivity(intent)
            proxyStatus?.text = "Android certificate installer opened. Trust is controlled by Android and must be explicitly approved by you."
        } catch (e: Exception) { proxyStatus?.text = "Unable to open certificate installer: ${e.message}" }
    }

    private fun renderProxySessions() {
        val root = proxyList ?: return
        root.removeAllViews()
        if (AppState.proxySessions.isEmpty()) {
            root.addView(Ui.sectionHeader(this, "HISTORY", "No web sessions", "Start the proxy, configure a compatible browser/client to use 127.0.0.1:${AppState.proxyPort}, then browse or send requests.")); return
        }
        AppState.proxySessions.take(100).forEach { s ->
            val c = Ui.card(this, 12)
            c.addView(Ui.text(this, "${s.method}  ${s.status}  ${s.type}", 13f, Ui.WHITE, true))
            Ui.addGap(c, this, 4); c.addView(Ui.subtitle(this, "${s.url}\n${s.durationMs} ms${if (s.observation.isNotBlank()) "\nObservation: ${s.observation}" else ""}"))
            Ui.addGap(c, this, 8)
            c.addView(Ui.whiteButton(this, "SEND TO REPEATER") { loadRepeater(s); showPage("REPEATER") })
            root.addView(c); root.addView(Space(this), LinearLayout.LayoutParams(1, Ui.dp(this, 8)))
        }
    }

    private fun loadRepeater(s: ProxySession) {
        pendingRepeater = s
    }
    private var pendingRepeater: ProxySession? = null

    private fun buildRepeater() {
        pageIntro("Repeater", "Quick HTTP + full request editor", "Use one-tap basic HTTP requests for fast diagnostics, or edit and resend complete HTTP/S requests with custom headers and body content.")

        val quick = Ui.card(this)
        quick.addView(Ui.text(this, "QUICK REQUESTS", 10f, Ui.MUTED, true)); Ui.addGap(quick, this, 5)
        quick.addView(Ui.text(this, "Basic HTTP in one tap", 19f, Ui.WHITE, true)); Ui.addGap(quick, this, 5)
        quick.addView(Ui.subtitle(this, "GET, HEAD and OPTIONS are useful for quick reachability, response-header and method checks. POST JSON loads a small editable JSON request."))
        Ui.addGap(quick, this, 8)
        val quickUrl = Ui.input(this, "https://example.com/", pendingRepeater?.url ?: "https://example.com/")
        quick.addView(quickUrl); Ui.addGap(quick, this, 8)
        val qr1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        qr1.addView(Ui.whiteButton(this, "GET") { runQuickRequest("GET", quickUrl.text.toString()) }, LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f).apply { marginEnd = Ui.dp(this@MainActivity, 6) })
        qr1.addView(Ui.whiteButton(this, "HEAD") { runQuickRequest("HEAD", quickUrl.text.toString()) }, LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f).apply { marginEnd = Ui.dp(this@MainActivity, 6) })
        qr1.addView(Ui.whiteButton(this, "OPTIONS") { runQuickRequest("OPTIONS", quickUrl.text.toString()) }, LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f))
        quick.addView(qr1); Ui.addGap(quick, this, 7)
        val qr2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        qr2.addView(Ui.whiteButton(this, "GET /robots.txt") {
            val base = quickUrl.text.toString().trimEnd('/')
            runQuickRequest("GET", "$base/robots.txt")
        }, LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f).apply { marginEnd = Ui.dp(this@MainActivity, 6) })
        qr2.addView(Ui.whiteButton(this, "POST JSON") {
            pendingRepeater = ProxySession(method = "POST", url = quickUrl.text.toString(), status = 0, type = "QUICK", requestHeaders = "User-Agent: Saphaea-Inspector-Mobile/0.2\nAccept: application/json\nContent-Type: application/json", requestBody = "{\n  \"test\": true\n}")
            showPage("REPEATER")
        }, LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f))
        quick.addView(qr2)
        repeaterOutput = Ui.monoBox(this, "Quick response appears here.").apply { minLines = 8 }
        Ui.addGap(quick, this, 9); quick.addView(repeaterOutput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 280)))
        mainContent.addView(quick)
        Ui.addGap(mainContent, this, 12)

        val box = Ui.card(this)
        box.addView(Ui.text(this, "FULL REQUEST EDITOR", 10f, Ui.MUTED, true)); Ui.addGap(box, this, 7)
        repeaterMethod = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"))
            background = Ui.rounded(Ui.WHITE, Ui.dp(this@MainActivity, 10).toFloat())
        }
        repeaterUrl = Ui.input(this, "https://example.com/", quickUrl.text.toString())
        repeaterHeaders = Ui.monoBox(this, "User-Agent: Saphaea-Inspector-Mobile/0.2\nAccept: */*").apply { minLines = 4 }
        repeaterBody = Ui.monoBox(this, "").apply { hint = "Request body"; minLines = 5 }
        box.addView(repeaterMethod); Ui.addGap(box, this, 7); box.addView(repeaterUrl); Ui.addGap(box, this, 7); box.addView(repeaterHeaders); Ui.addGap(box, this, 7); box.addView(repeaterBody); Ui.addGap(box, this, 9)
        box.addView(Ui.whiteButton(this, "SEND REQUEST") { sendRepeater() })
        Ui.addGap(box, this, 9)
        val fullOutput = Ui.monoBox(this, "Full response appears here.").apply { minLines = 12 }
        box.addView(fullOutput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 420)))
        mainContent.addView(box)
        pendingRepeater?.let { s ->
            val idx = (repeaterMethod?.adapter as? ArrayAdapter<String>)?.let { a -> (0 until a.count).firstOrNull { a.getItem(it) == s.method } } ?: 0
            repeaterMethod?.setSelection(idx ?: 0)
            repeaterUrl?.setText(s.url)
            repeaterHeaders?.setText(s.requestHeaders)
            repeaterBody?.setText(s.requestBody)
            quickUrl.setText(s.url)
            pendingRepeater = null
        }
        repeaterOutput?.tag = fullOutput
    }

    private fun runQuickRequest(method: String, url: String) {
        repeaterOutput?.setText("Sending $method…")
        scope.launch {
            val out = withContext(Dispatchers.IO) { proxy.repeat(method, url, "User-Agent: Saphaea-Inspector-Mobile/0.2\nAccept: */*", "") }
            repeaterOutput?.setText(out)
        }
    }

    private fun sendRepeater() {
        val method = repeaterMethod?.selectedItem?.toString() ?: "GET"
        val url = repeaterUrl?.text?.toString().orEmpty()
        val headers = repeaterHeaders?.text?.toString().orEmpty()
        val body = repeaterBody?.text?.toString().orEmpty()
        val fullOutput = repeaterOutput?.tag as? EditText
        fullOutput?.setText("Sending…")
        scope.launch {
            val out = withContext(Dispatchers.IO) { proxy.repeat(method, url, headers, body) }
            fullOutput?.setText(out)
        }
    }

    private fun buildAnalyze() {
        pageIntro("Analyze", "Turn packets and devices into intelligence", "Correlate transport and application protocols, endpoints, ports, conversations, DNS/TLS/HTTP names, packet signals, discovered-device fingerprints, Wi-Fi posture and web observations.")
        analyzeRoot = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mainContent.addView(analyzeRoot)
        renderAnalyze()
    }

    private fun renderAnalyze() {
        val root = analyzeRoot ?: return
        root.removeAllViews()
        val packets = AppState.packets.toList()
        val protocols = packets.groupingBy { it.protocol }.eachCount().toList().sortedByDescending { it.second }
        val apps = packets.groupingBy { it.appProtocol.ifBlank { it.protocol } }.eachCount().toList().sortedByDescending { it.second }
        val endpoints = mutableMapOf<String, Pair<Int, Long>>()
        val ports = mutableMapOf<String, Pair<Int, Long>>()
        val conversations = mutableMapOf<String, Pair<Int, Long>>()
        packets.forEach { p ->
            listOf(p.source, p.destination).forEach { ep ->
                val old = endpoints[ep] ?: (0 to 0L)
                endpoints[ep] = old.first + 1 to old.second + p.length
            }
            listOfNotNull(p.sourcePort, p.destinationPort).forEach { port ->
                val key = "${p.protocol}/$port"
                val old = ports[key] ?: (0 to 0L)
                ports[key] = old.first + 1 to old.second + p.length
            }
            val left = "${p.source}${p.sourcePort?.let { ":$it" }.orEmpty()}"
            val right = "${p.destination}${p.destinationPort?.let { ":$it" }.orEmpty()}"
            val key = if (left <= right) "$left ↔ $right" else "$right ↔ $left"
            val old = conversations[key] ?: (0 to 0L)
            conversations[key] = old.first + 1 to old.second + p.length
        }
        val summary = Ui.card(this)
        summary.addView(Ui.text(this, "SUMMARY", 10f, Ui.MUTED, true)); Ui.addGap(summary, this, 6)
        summary.addView(Ui.text(this, "${packets.size} packets • ${AppState.proxySessions.size} web sessions • ${AppState.devices.size} devices • ${AppState.wifi.size} Wi-Fi APs", 17f, Ui.WHITE, true))
        root.addView(summary); root.addView(Space(this), LinearLayout.LayoutParams(1, Ui.dp(this, 8)))

        fun analysisCard(label: String, text: String, lines: Int = 5) {
            val card = Ui.card(this)
            card.addView(Ui.text(this, label, 10f, Ui.MUTED, true)); Ui.addGap(card, this, 6)
            card.addView(Ui.monoBox(this, text).apply { isFocusable = false; minLines = lines; maxLines = 14 })
            root.addView(card); root.addView(Space(this), LinearLayout.LayoutParams(1, Ui.dp(this, 8)))
        }

        analysisCard("APPLICATION PROTOCOLS", if (apps.isEmpty()) "No packet data yet." else apps.joinToString("\n") { String.format("%-12s %6d", it.first.take(12), it.second) }, 4)
        analysisCard("TRANSPORT / NETWORK", if (protocols.isEmpty()) "No packet data yet." else protocols.joinToString("\n") { String.format("%-12s %6d", it.first, it.second) }, 3)
        val epText = endpoints.entries.sortedByDescending { it.value.second }.take(30).joinToString("\n") { String.format("%-25s %5d pkts  %s", it.key.take(25), it.value.first, formatBytes(it.value.second)) }
        analysisCard("TOP ENDPOINTS", epText.ifBlank { "No endpoint data yet." }, 5)
        val portText = ports.entries.sortedByDescending { it.value.first }.take(30).joinToString("\n") { String.format("%-12s %5d pkts  %s", it.key, it.value.first, formatBytes(it.value.second)) }
        analysisCard("TOP PORTS", portText.ifBlank { "No port data yet." }, 5)
        val convText = conversations.entries.sortedByDescending { it.value.second }.take(30).joinToString("\n") { String.format("%-38s %4d  %s", it.key.take(38), it.value.first, formatBytes(it.value.second)) }
        analysisCard("CONVERSATIONS", convText.ifBlank { "No conversation data yet." }, 6)

        val names = packets.mapNotNull { p ->
            when {
                p.dnsName.isNotBlank() -> "${p.appProtocol.ifBlank { p.protocol }}  ${p.dnsName}"
                p.info.contains("Host=") -> "HTTP  ${p.info.substringAfter("Host=").substringBefore(' ')}"
                else -> null
            }
        }.distinct().take(80)
        analysisCard("DNS / TLS / HTTP NAMES", names.joinToString("\n").ifBlank { "No decoded names yet. DNS questions and TLS SNI will appear here when captured." }, 6)

        val signals = mutableListOf<String>()
        val rst = packets.count { it.tcpFlags.contains("RST") }
        val syn = packets.count { it.tcpFlags.contains("SYN") && !it.tcpFlags.contains("ACK") }
        val icmp = packets.count { it.protocol.startsWith("ICMP") }
        val http = packets.count { it.appProtocol == "HTTP" }
        val fragments = packets.count { it.info.contains("frag=") || it.info.contains(" MF") }
        if (syn > 0) signals += "$syn TCP SYN packet(s)"
        if (rst > 0) signals += "$rst TCP reset packet(s)"
        if (icmp > 0) signals += "$icmp ICMP packet(s)"
        if (fragments > 0) signals += "$fragments fragmented IPv4 packet(s)"
        if (http > 0) signals += "$http plaintext HTTP candidate packet(s)"
        analysisCard("PACKET SIGNALS", signals.joinToString("\n").ifBlank { "No notable packet signals yet." }, 4)

        val deviceText = AppState.devices.take(60).joinToString("\n\n") { d ->
            buildString {
                append("${d.ip}  ${d.host.ifBlank { d.role }}")
                if (d.vendor.isNotBlank()) append("  [${d.vendor}]")
                append("\n  ${d.role}${if (d.osHint.isNotBlank()) " • ${d.osHint}" else ""}")
                if (d.services.isNotBlank()) append("\n  ${d.services}")
                if (d.exposure.isNotBlank()) append("\n  ${d.exposure}")
            }
        }
        analysisCard("DEVICE INVENTORY", deviceText.ifBlank { "Run Network → Discovery to build device intelligence." }, 6)

        val wifiSecurity = AppState.wifi.groupingBy { w ->
            when {
                w.capabilities.contains("WPA3", true) -> "WPA3"
                w.capabilities.contains("WPA2", true) -> "WPA2"
                w.capabilities.contains("WPA", true) -> "WPA"
                w.capabilities.contains("WEP", true) -> "WEP"
                else -> "Open / unspecified"
            }
        }.eachCount().entries.sortedByDescending { it.value }.joinToString("\n") { "${it.key}: ${it.value}" }
        analysisCard("WI-FI POSTURE", wifiSecurity.ifBlank { "Run Network → Wi-Fi to analyze nearby advertised security modes." }, 4)

        val findings = AppState.proxySessions.mapNotNull { if (it.observation.isBlank()) null else "${it.status} ${it.url}\n  ${it.observation}" }.take(50)
        analysisCard("WEB OBSERVATIONS", findings.joinToString("\n\n").ifBlank { "No passive web observations yet." }, 6)
    }

    private fun buildCodec() {
        pageIntro("Codec", "Transform common web data", "Base64, URL and hexadecimal encoding/decoding without leaving the Inspector workspace.")
        val box = Ui.card(this)
        val input = Ui.monoBox(this, "Saphaea Inspector")
        val output = Ui.monoBox(this, "")
        box.addView(Ui.text(this, "INPUT", 10f, Ui.MUTED, true)); Ui.addGap(box, this, 5); box.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 190)))
        Ui.addGap(box, this, 8)
        val ops = listOf("BASE64 ENCODE", "BASE64 DECODE", "URL ENCODE", "URL DECODE", "HEX ENCODE", "HEX DECODE")
        ops.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, op ->
                row.addView(Ui.whiteButton(this, op) { output.setText(codec(op, input.text.toString())) }, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f).apply { if (i == 0 && pair.size > 1) marginEnd = Ui.dp(this@MainActivity, 8) })
            }
            box.addView(row); Ui.addGap(box, this, 7)
        }
        box.addView(Ui.text(this, "OUTPUT", 10f, Ui.MUTED, true)); Ui.addGap(box, this, 5); box.addView(output, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 220)))
        mainContent.addView(box)
    }

    private fun codec(op: String, s: String): String = try {
        when (op) {
            "BASE64 ENCODE" -> Base64.getEncoder().encodeToString(s.toByteArray())
            "BASE64 DECODE" -> String(Base64.getDecoder().decode(s.trim()))
            "URL ENCODE" -> URLEncoder.encode(s, StandardCharsets.UTF_8.name())
            "URL DECODE" -> URLDecoder.decode(s, StandardCharsets.UTF_8.name())
            "HEX ENCODE" -> s.toByteArray().joinToString("") { "%02x".format(it) }
            "HEX DECODE" -> s.replace(Regex("\\s+"), "").chunked(2).map { it.toInt(16).toByte() }.toByteArray().toString(Charsets.UTF_8)
            else -> s
        }
    } catch (e: Exception) { "Error: ${e.message}" }

    private fun buildGuide() {
        pageIntro("Guide", "Getting started with Inspector Mobile", "The same workflow as desktop Saphaea, adapted to Android's permission, Wi-Fi, VPN and certificate model.")
        val sections = listOf(
            Triple("1 — DISCOVER THE LAN", "Network → Discovery", "Use the suggested local /24 or enter an authorized CIDR. Fast Scan finds reachable hosts and names. Deep Scan also checks a small set of common service ports. MAC addresses are shown when Android exposes neighbor-table data."),
            Triple("2 — MAP WI-FI", "Network → Wi-Fi", "Grant Nearby Wi-Fi and Location permission, ensure Android Location services are enabled, then scan. Results include SSID, BSSID, signal, channel, frequency and security capabilities."),
            Triple("3 — VISUALIZE", "Network → Topology", "After Discovery, open Topology to see the gateway and discovered nodes. Monitor shows live aggregate Android receive/transmit throughput without constant UI redraws."),
            Triple("4 — CAPTURE", "Capture", "Tap Start Raw Capture and approve Android's VPN prompt. v0.2 decodes IPv4/IPv6 headers, TCP flags, UDP, ICMP, DNS/mDNS, HTTP hosts/request lines, TLS SNI, QUIC candidates and common application protocols. Important: the alpha capture engine does not forward tunneled traffic yet, so network activity can pause while raw capture is active."),
            Triple("5 — WEB PROXY", "Proxy", "Start the local proxy on 127.0.0.1:8080. HTTP is inspected directly. HTTPS CONNECT can tunnel normally, or you can explicitly generate/install the Saphaea CA and enable HTTPS inspection for compatible clients."),
            Triple("6 — REPEATER", "Repeater", "Use GET/HEAD/OPTIONS/robots.txt quick buttons, load a POST JSON template, build a request manually, or tap Send to Repeater from a captured proxy session. Edit the method, URL, headers and body, then inspect the complete response."),
            Triple("7 — ANALYZE", "Analyze", "Review application protocols, endpoints, ports, conversations, decoded DNS/TLS/HTTP names, packet signals, device fingerprints, Wi-Fi posture, web sessions and passive security-header/cookie observations. This is the higher-level layer above raw packet rows."),
            Triple("AUTHORIZED USE", "Scope", "Use Saphaea on systems, apps and networks you own or are authorized to test. The app binds proxy services to loopback by default and requires explicit Android approval for VPN capture and certificate trust.")
        )
        sections.forEach { s ->
            val c = Ui.card(this)
            c.addView(Ui.text(this, s.first, 11f, Ui.MUTED, true)); Ui.addGap(c, this, 5); c.addView(Ui.text(this, s.second, 18f, Ui.WHITE, true)); Ui.addGap(c, this, 5); c.addView(Ui.subtitle(this, s.third))
            mainContent.addView(c); Ui.addGap(mainContent, this, 8)
        }
    }

    private fun buildSettings() {
        pageIntro("Settings", "Android integration and status", "Permission, certificate and implementation status for Saphaea Inspector Mobile.")
        val info = engine.getLocalInfo()
        val card = Ui.card(this)
        card.addView(Ui.text(this, "PRODUCT", 10f, Ui.MUTED, true)); Ui.addGap(card, this, 6)
        card.addView(Ui.text(this, "Saphaea Inspector Mobile 0.2 Alpha", 19f, Ui.WHITE, true)); Ui.addGap(card, this, 5)
        card.addView(Ui.subtitle(this, "Package com.saphaea.inspector.mobile\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nNetwork ${info.transport} • ${info.ip.ifBlank { "no IPv4" }}\nLocal CA ${if (proxy.ca.exists()) "generated" else "not generated"}\nProxy ${if (AppState.proxyRunning) "running" else "stopped"}\nRaw capture ${if (AppState.vpnCaptureRunning) "active" else "idle"}"))
        Ui.addGap(card, this, 10)
        card.addView(Ui.whiteButton(this, "REQUEST NETWORK PERMISSIONS") { ensureWifiPermissionsAndScan() })
        Ui.addGap(card, this, 7)
        card.addView(Ui.whiteButton(this, "INSTALL / REINSTALL SAPHAEA CA") { installCa() })
        mainContent.addView(card)
        Ui.addGap(mainContent, this, 10)
        mainContent.addView(Ui.sectionHeader(this, "DESIGN", "Mobile parity, not a literal desktop resize", "The mobile build keeps Saphaea's black institutional shell, white controls with black text, rounded cards, readable telemetry and the desktop workflow while adapting dense tables into touch-friendly cards."))
    }

    private fun refreshDynamic() {
        renderOverviewMetrics()
        if (currentPage == "NETWORK") when (currentNetworkPage) {
            "DISCOVERY" -> renderDevices()
            "WIFI" -> renderWifi()
            "TOPOLOGY" -> topologyView?.devices = AppState.devices.toList()
        }
        if (currentPage == "CAPTURE") {
            val f = (captureList?.tag as? EditText)?.text?.toString().orEmpty()
            renderPackets(f)
        }
        if (currentPage == "PROXY") renderProxySessions()
        if (currentPage == "ANALYZE") renderAnalyze()
    }

    private fun formatBytes(v: Long): String {
        val n = v.toDouble()
        return when {
            v < 1024 -> "$v B"
            v < 1024 * 1024 -> String.format("%.1f KB", n / 1024.0)
            v < 1024L * 1024 * 1024 -> String.format("%.1f MB", n / 1024.0 / 1024.0)
            else -> String.format("%.2f GB", n / 1024.0 / 1024.0 / 1024.0)
        }
    }
}
