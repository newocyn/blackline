package com.saphaea.inspector.mobile

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.setPadding
import java.text.SimpleDateFormat
import java.util.*

object Ui {
    const val BLACK = 0xFF050505.toInt()
    const val PANEL = 0xFF111111.toInt()
    const val PANEL2 = 0xFF171717.toInt()
    const val LINE = 0xFF2A2A2A.toInt()
    const val WHITE = Color.WHITE
    const val MUTED = 0xFFA9B0BA.toInt()

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radius: Float = 18f, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (stroke != null) setStroke(1, stroke)
    }

    fun text(c: Context, value: String, size: Float = 14f, color: Int = WHITE, bold: Boolean = false): TextView = TextView(c).apply {
        text = value
        textSize = size
        setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        includeFontPadding = false
    }

    fun title(c: Context, value: String): TextView = text(c, value, 26f, WHITE, true)
    fun subtitle(c: Context, value: String): TextView = text(c, value, 14f, MUTED, false)

    fun vbox(c: Context, gap: Int = 8): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(c, gap))
    }

    fun hbox(c: Context, gap: Int = 8): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(c, gap))
    }

    fun card(c: Context, padding: Int = 16): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(c, padding))
        background = rounded(PANEL, dp(c, 14).toFloat(), LINE)
    }

    fun whiteButton(c: Context, label: String, onClick: () -> Unit): Button = Button(c).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.BLACK)
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(Color.WHITE, dp(c, 12).toFloat(), 0xFFD5D5D5.toInt())
        minHeight = dp(c, 44)
        minimumHeight = dp(c, 44)
        setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8))
        setOnClickListener { onClick() }
    }

    fun darkButton(c: Context, label: String, onClick: () -> Unit): Button = Button(c).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(PANEL2, dp(c, 12).toFloat(), LINE)
        minHeight = dp(c, 44)
        setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8))
        setOnClickListener { onClick() }
    }

    fun input(c: Context, hintText: String, value: String = ""): EditText = EditText(c).apply {
        hint = hintText
        setHintTextColor(0xFF737A84.toInt())
        setTextColor(WHITE)
        setText(value)
        textSize = 14f
        isSingleLine = true
        background = rounded(PANEL2, dp(c, 10).toFloat(), LINE)
        setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10))
    }

    fun monoBox(c: Context, value: String = ""): EditText = EditText(c).apply {
        setText(value)
        setTextColor(0xFFE9EDF2.toInt())
        setHintTextColor(0xFF737A84.toInt())
        textSize = 12f
        typeface = Typeface.MONOSPACE
        gravity = Gravity.TOP or Gravity.START
        setPadding(dp(c, 12))
        background = rounded(PANEL2, dp(c, 10).toFloat(), LINE)
        minLines = 7
        isSingleLine = false
        setHorizontallyScrolling(false)
    }

    fun addGap(parent: LinearLayout, c: Context, h: Int = 10) {
        parent.addView(Space(c), LinearLayout.LayoutParams(1, dp(c, h)))
    }

    fun add(parent: LinearLayout, child: View, width: Int = ViewGroup.LayoutParams.MATCH_PARENT, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f, marginTop: Int = 0) {
        val lp = LinearLayout.LayoutParams(width, height, weight)
        if (marginTop > 0) lp.topMargin = dp(parent.context, marginTop)
        parent.addView(child, lp)
    }

    fun sectionHeader(c: Context, eyebrow: String, heading: String, body: String): LinearLayout = card(c).apply {
        addView(text(c, eyebrow.uppercase(), 11f, MUTED, true))
        addGap(this, c, 6)
        addView(text(c, heading, 20f, WHITE, true))
        addGap(this, c, 6)
        addView(text(c, body, 13f, MUTED))
    }

    fun metricCard(c: Context, label: String, value: String, sub: String): LinearLayout = card(c).apply {
        addView(text(c, label.uppercase(), 10f, MUTED, true))
        addGap(this, c, 8)
        addView(text(c, value, 27f, WHITE, true))
        addGap(this, c, 4)
        addView(text(c, sub, 12f, MUTED))
    }

    fun time(ts: Long): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(ts))
}
