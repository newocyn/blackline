package com.saphaea.inspector.mobile

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.*
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import kotlin.math.pow

class NetworkEngine(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val commonPorts = linkedMapOf(
        21 to "FTP", 22 to "SSH", 23 to "Telnet", 25 to "SMTP", 53 to "DNS",
        80 to "HTTP", 110 to "POP3", 139 to "NetBIOS", 143 to "IMAP", 389 to "LDAP",
        443 to "HTTPS", 445 to "SMB", 548 to "AFP", 631 to "IPP", 1883 to "MQTT",
        3000 to "HTTP-alt", 3389 to "RDP", 5000 to "HTTP-alt", 5900 to "VNC",
        8000 to "HTTP-alt", 8080 to "HTTP-alt", 8443 to "HTTPS-alt", 8888 to "HTTP-alt", 9100 to "Printer"
    )
    private val quickProbePorts = listOf(22, 80, 443, 445, 3389, 8080, 9100)

    data class LocalInfo(
        val ip: String = "",
        val prefixLength: Int = 24,
        val gateway: String = "",
        val dns: List<String> = emptyList(),
        val interfaceName: String = "",
        val transport: String = ""
    )

    private data class ServiceHit(val port: Int, val name: String, val detail: String = "")

    fun getLocalInfo(): LocalInfo {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return LocalInfo()
        val caps = cm.getNetworkCapabilities(network)
        val lp = cm.getLinkProperties(network) ?: return LocalInfo()
        val ipv4 = lp.linkAddresses.firstOrNull { it.address is Inet4Address }
        val gateway = lp.routes.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.hostAddress ?: ""
        val transport = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Cellular"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true -> "VPN"
            else -> "Network"
        }
        return LocalInfo(
            ip = ipv4?.address?.hostAddress ?: "",
            prefixLength = ipv4?.prefixLength ?: 24,
            gateway = gateway,
            dns = lp.dnsServers.mapNotNull { it.hostAddress },
            interfaceName = lp.interfaceName ?: "",
            transport = transport
        )
    }

    fun suggestedCidr(): String {
        val info = getLocalInfo()
        if (info.ip.isBlank()) return "192.168.1.0/24"
        val parts = info.ip.split('.')
        return if (parts.size == 4) "${parts[0]}.${parts[1]}.${parts[2]}.0/24" else "192.168.1.0/24"
    }

    fun scanLan(cidr: String, deep: Boolean, progress: (Int, Int) -> Unit, done: (List<NetworkDevice>) -> Unit) {
        scope.launch {
            AppState.deepScan = deep
            val info = getLocalInfo()
            val hosts = hostsForCidr(cidr).take(512)
            val found = ConcurrentHashMap<String, NetworkDevice>()
            val ssdp = if (deep) discoverSsdp() else emptyMap()
            val semaphore = kotlinx.coroutines.sync.Semaphore(if (deep) 36 else 64)
            val jobs = hosts.mapIndexed { index, ip ->
                async {
                    semaphore.acquire()
                    try {
                        val start = System.nanoTime()
                        val addr = InetAddress.getByName(ip)
                        val reachable = try { addr.isReachable(if (deep) 350 else 500) } catch (_: Exception) { false }
                        val quickOpen = if (deep && !reachable) quickProbe(ip) else emptyList()
                        val discovered = reachable || quickOpen.isNotEmpty() || ip == info.gateway || ip == info.ip || ssdp.containsKey(ip)
                        if (discovered) {
                            val latency = (System.nanoTime() - start) / 1_000_000
                            val host = try {
                                val n = addr.canonicalHostName
                                if (n == ip) "" else n
                            } catch (_: Exception) { "" }
                            val hits = if (deep) scanCommonPortsDetailed(ip) else quickOpen.map { ServiceHit(it, commonPorts[it] ?: "TCP") }
                            val ssdpText = ssdp[ip].orEmpty()
                            val serviceNames = hits.map { "${it.port}/${it.name}" }
                            val details = buildList {
                                hits.filter { it.detail.isNotBlank() }.forEach { add("${it.port}/${it.name}: ${it.detail}") }
                                if (ssdpText.isNotBlank()) add(ssdpText)
                            }.joinToString("\n")
                            val web = if (deep) bestWebFingerprint(ip, hits) else ""
                            val role = inferRole(ip, info, host, hits, details)
                            val os = inferOs(host, details, hits)
                            val vendor = inferVendor(host, details, "")
                            val exposure = exposureSummary(hits)
                            found[ip] = NetworkDevice(
                                ip = ip,
                                host = host,
                                vendor = vendor,
                                latencyMs = latency,
                                role = role,
                                osHint = os,
                                services = serviceNames.joinToString(", "),
                                serviceDetails = details,
                                webTitle = web,
                                exposure = exposure,
                                isGateway = ip == info.gateway,
                                isLocal = ip == info.ip
                            )
                        }
                    } finally {
                        semaphore.release()
                        withContext(Dispatchers.Main) { progress(index + 1, hosts.size) }
                    }
                }
            }
            jobs.awaitAll()

            // Add SSDP-only nodes that fell outside ping/port visibility but are still in the requested range.
            ssdp.forEach { (ip, detail) ->
                if (found[ip] == null && hosts.contains(ip)) {
                    found[ip] = NetworkDevice(ip = ip, role = "UPnP / media device", serviceDetails = detail, exposure = "SSDP advertised")
                }
            }

            val neighbors = parseNeighbors(command("ip neigh show"))
            found.values.forEach { d ->
                if (d.mac.isBlank()) d.mac = neighbors[d.ip].orEmpty()
                if (d.vendor.isBlank()) d.vendor = inferVendor(d.host, d.serviceDetails, d.mac)
                if (d.mac.isNotBlank() && isLocallyAdministeredMac(d.mac) && d.vendor.isBlank()) d.vendor = "Randomized / local MAC"
            }
            val result = found.values.sortedWith(compareBy<NetworkDevice> { ipv4Number(it.ip) })
            AppState.devices.clear(); AppState.devices.addAll(result); AppState.changed()
            withContext(Dispatchers.Main) { done(result) }
        }
    }

    private fun inferRole(ip: String, info: LocalInfo, host: String, hits: List<ServiceHit>, detail: String): String {
        if (ip == info.ip) return "This Android device"
        if (ip == info.gateway) return "Gateway / router"
        val text = (host + " " + detail + " " + hits.joinToString(" ") { it.name }).lowercase()
        return when {
            listOf("printer", "ipp", "9100", "epson", "brother", "canon", "laserjet").any { text.contains(it) } -> "Printer"
            listOf("chromecast", "roku", "airplay", "media renderer", "dlna").any { text.contains(it) } -> "Media / streaming"
            listOf("camera", "rtsp", "nvr", "hikvision", "reolink").any { text.contains(it) } -> "Camera / NVR"
            listOf("unifi", "ubiquiti", "mikrotik", "router", "access point").any { text.contains(it) } -> "Network infrastructure"
            hits.any { it.port == 3389 || it.port == 445 } -> "Computer / server"
            hits.any { it.port == 22 } && hits.any { it.port == 80 || it.port == 443 || it.port == 8080 } -> "Server / appliance"
            hits.any { it.port in listOf(80, 443, 8080, 8443, 8000, 8888, 3000, 5000) } -> "Web device / appliance"
            detail.contains("ssdp", true) || detail.contains("upnp", true) -> "UPnP / smart device"
            else -> "Network device"
        }
    }

    private fun inferOs(host: String, detail: String, hits: List<ServiceHit>): String {
        val t = "$host $detail".lowercase()
        return when {
            "microsoft" in t || "windows" in t || "iis" in t || hits.any { it.port == 3389 } -> "Windows / Microsoft stack"
            "ubuntu" in t || "debian" in t || "openssh" in t || "nginx" in t || "apache" in t -> "Linux / Unix-like"
            "synology" in t -> "Synology DSM"
            "qnap" in t -> "QNAP QTS"
            "apple" in t || "airplay" in t || "iphone" in t || "ipad" in t || "macbook" in t -> "Apple platform"
            "android" in t || "chromecast" in t -> "Android / Google platform"
            else -> ""
        }
    }

    private fun inferVendor(host: String, detail: String, mac: String): String {
        val t = "$host $detail".lowercase()
        return when {
            "ubiquiti" in t || "unifi" in t -> "Ubiquiti"
            "tp-link" in t || "tplink" in t -> "TP-Link"
            "mikrotik" in t -> "MikroTik"
            "synology" in t -> "Synology"
            "qnap" in t -> "QNAP"
            "raspberry" in t -> "Raspberry Pi"
            "epson" in t -> "Epson"
            "brother" in t -> "Brother"
            "canon" in t -> "Canon"
            "hewlett" in t || "laserjet" in t || " hp " in " $t " -> "HP"
            "samsung" in t -> "Samsung"
            "motorola" in t -> "Motorola"
            "chromecast" in t || "google" in t -> "Google"
            "roku" in t -> "Roku"
            "amazon" in t || "echo" in t -> "Amazon"
            "apple" in t || "iphone" in t || "ipad" in t || "macbook" in t -> "Apple"
            mac.isNotBlank() && isLocallyAdministeredMac(mac) -> "Randomized / local MAC"
            else -> ""
        }
    }

    private fun exposureSummary(hits: List<ServiceHit>): String {
        if (hits.isEmpty()) return "No common TCP services detected"
        val notes = mutableListOf<String>()
        if (hits.any { it.port in listOf(21, 23, 80, 110, 143) }) notes += "Plaintext-capable service"
        if (hits.any { it.port in listOf(22, 3389, 5900) }) notes += "Remote administration"
        if (hits.any { it.port in listOf(445, 139, 548) }) notes += "File sharing"
        if (hits.any { it.port in listOf(80, 443, 8080, 8443, 8000, 8888, 3000, 5000) }) notes += "Web management"
        if (hits.any { it.port in listOf(631, 9100) }) notes += "Printing"
        return notes.distinct().joinToString(" • ").ifBlank { "${hits.size} common service(s) visible" }
    }

    private suspend fun quickProbe(ip: String): List<Int> = coroutineScope {
        quickProbePorts.map { port ->
            async {
                val ok = try { Socket().use { s -> s.connect(InetSocketAddress(ip, port), 140); true } } catch (_: Exception) { false }
                if (ok) port else null
            }
        }.awaitAll().filterNotNull()
    }

    private suspend fun scanCommonPortsDetailed(ip: String): List<ServiceHit> = coroutineScope {
        commonPorts.map { (port, name) ->
            async {
                val open = try { Socket().use { s -> s.connect(InetSocketAddress(ip, port), 220); true } } catch (_: Exception) { false }
                if (!open) null else ServiceHit(port, name, fingerprintService(ip, port, name))
            }
        }.awaitAll().filterNotNull().sortedBy { it.port }
    }

    private fun fingerprintService(ip: String, port: Int, name: String): String {
        return try {
            when {
                name.startsWith("HTTP") && !name.startsWith("HTTPS") -> httpFingerprint(ip, port, false)
                name.startsWith("HTTPS") -> httpFingerprint(ip, port, true)
                port in listOf(21, 22, 23, 25, 110, 143) -> bannerFingerprint(ip, port)
                else -> "open"
            }
        } catch (_: Exception) { "open" }
    }

    private fun bannerFingerprint(ip: String, port: Int): String {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(ip, port), 500)
                s.soTimeout = 500
                val line = BufferedReader(InputStreamReader(s.getInputStream())).readLine().orEmpty()
                line.replace(Regex("[\\r\\n]+"), " ").take(180).ifBlank { "open" }
            }
        } catch (_: Exception) { "open" }
    }

    private fun httpFingerprint(ip: String, port: Int, tls: Boolean): String {
        val scheme = if (tls) "https" else "http"
        val url = URL("$scheme://$ip:$port/")
        val conn = if (tls) {
            val c = url.openConnection() as javax.net.ssl.HttpsURLConnection
            c.sslSocketFactory = trustAllSslContext().socketFactory
            c.hostnameVerifier = javax.net.ssl.HostnameVerifier { _, _ -> true }
            c
        } else url.openConnection() as HttpURLConnection
        return try {
            conn.connectTimeout = 650
            conn.readTimeout = 800
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", "Saphaea-Inspector-Mobile/0.2")
            conn.connect()
            val server = conn.getHeaderField("Server").orEmpty()
            val powered = conn.getHeaderField("X-Powered-By").orEmpty()
            val code = try { conn.responseCode } catch (_: Exception) { -1 }
            buildString {
                if (code > 0) append("HTTP $code")
                if (server.isNotBlank()) append(" server=$server")
                if (powered.isNotBlank()) append(" powered=$powered")
            }.trim().ifBlank { "open" }.take(220)
        } finally { conn.disconnect() }
    }

    private fun bestWebFingerprint(ip: String, hits: List<ServiceHit>): String {
        val hit = hits.firstOrNull { it.port in listOf(80, 8080, 8000, 8888, 3000, 5000) }
            ?: hits.firstOrNull { it.port in listOf(443, 8443) }
            ?: return ""
        val tls = hit.port in listOf(443, 8443)
        return try {
            val scheme = if (tls) "https" else "http"
            val url = URL("$scheme://$ip:${hit.port}/")
            val conn = if (tls) {
                val c = url.openConnection() as javax.net.ssl.HttpsURLConnection
                c.sslSocketFactory = trustAllSslContext().socketFactory
                c.hostnameVerifier = javax.net.ssl.HostnameVerifier { _, _ -> true }
                c
            } else url.openConnection() as HttpURLConnection
            conn.connectTimeout = 700; conn.readTimeout = 850
            conn.setRequestProperty("User-Agent", "Saphaea-Inspector-Mobile/0.2")
            val body = try { conn.inputStream.bufferedReader().use { it.readText().take(18_000) } } catch (_: Exception) { "" }
            val title = Regex("(?is)<title[^>]*>(.*?)</title>").find(body)?.groupValues?.getOrNull(1)?.replace(Regex("\\s+"), " ")?.trim().orEmpty()
            val server = conn.getHeaderField("Server").orEmpty()
            buildString {
                if (title.isNotBlank()) append("$title")
                if (server.isNotBlank()) { if (isNotEmpty()) append(" • "); append(server) }
            }.take(220)
        } catch (_: Exception) { "" }
    }

    private fun trustAllSslContext(): SSLContext {
        val tm = arrayOf<TrustManager>(object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        })
        return SSLContext.getInstance("TLS").apply { init(null, tm, SecureRandom()) }
    }

    private fun discoverSsdp(): Map<String, String> {
        val found = linkedMapOf<String, String>()
        try {
            DatagramSocket().use { socket ->
                socket.soTimeout = 250
                val request = ("M-SEARCH * HTTP/1.1\r\n" +
                    "HOST: 239.255.255.250:1900\r\n" +
                    "MAN: \"ssdp:discover\"\r\n" +
                    "MX: 1\r\n" +
                    "ST: ssdp:all\r\n\r\n").toByteArray()
                socket.send(DatagramPacket(request, request.size, InetAddress.getByName("239.255.255.250"), 1900))
                val end = System.currentTimeMillis() + 1100
                while (System.currentTimeMillis() < end) {
                    try {
                        val buf = ByteArray(4096)
                        val packet = DatagramPacket(buf, buf.size)
                        socket.receive(packet)
                        val raw = String(packet.data, packet.offset, packet.length, Charsets.ISO_8859_1)
                        val server = headerValue(raw, "SERVER")
                        val st = headerValue(raw, "ST")
                        val location = headerValue(raw, "LOCATION")
                        val detail = listOfNotNull(
                            server.takeIf { it.isNotBlank() }?.let { "server=$it" },
                            st.takeIf { it.isNotBlank() }?.let { "type=$it" },
                            location.takeIf { it.isNotBlank() }?.let { "location=$it" }
                        ).joinToString(" • ")
                        found[packet.address.hostAddress.orEmpty()] = "SSDP ${detail.ifBlank { "advertised" }}"
                    } catch (_: SocketTimeoutException) {}
                }
            }
        } catch (_: Exception) {}
        return found
    }

    private fun headerValue(raw: String, key: String): String = raw.lineSequence().firstOrNull { it.substringBefore(':').trim().equals(key, true) }?.substringAfter(':')?.trim().orEmpty()

    fun ping(target: String): String = command("ping -c 4 -W 2 ${shellSafe(target)}")

    fun dns(target: String): String {
        return try {
            val all = InetAddress.getAllByName(target)
            buildString {
                appendLine("DNS / ADDRESS LOOKUP")
                all.forEach { appendLine("${it.hostAddress}    ${it.canonicalHostName}") }
            }.trim()
        } catch (e: Exception) { "Lookup failed: ${e.message}" }
    }

    fun tcpCheck(target: String, portsText: String = "22,53,80,443,445,3389,8080"): String {
        val ports = portsText.split(',', ' ').mapNotNull { it.trim().toIntOrNull() }.distinct().take(64)
        return buildString {
            appendLine("TCP CONNECTIVITY — $target")
            ports.forEach { port ->
                val start = System.nanoTime()
                val ok = try { Socket().use { it.connect(InetSocketAddress(target, port), 650); true } } catch (_: Exception) { false }
                val ms = (System.nanoTime() - start) / 1_000_000
                appendLine(String.format("%-6d %-7s %4d ms", port, if (ok) "OPEN" else "closed", ms))
            }
        }.trim()
    }

    fun trace(target: String): String {
        val out = command("traceroute ${shellSafe(target)}")
        return if (out.contains("not found", true) || out.isBlank()) {
            "Traceroute binary is not available on this Android build.\n\nConnectivity fallback:\n${ping(target)}"
        } else out
    }

    fun neighbors(): String = command("ip neigh show")
    fun routes(): String = command("ip route show")
    fun interfaces(): String = command("ip addr show")

    @SuppressLint("MissingPermission")
    fun scanWifi(done: (List<WifiNetwork>, String?) -> Unit) {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val nearby = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED
        if (!fine || !nearby) {
            done(emptyList(), "Wi-Fi scanning needs Nearby Wi-Fi Devices and Location permission on this Android version.")
            return
        }
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        try { wm.startScan() } catch (_: Exception) {}
        scope.launch {
            delay(1700)
            val results = try { wm.scanResults } catch (_: Exception) { emptyList() }
            val mapped = results.map { r ->
                WifiNetwork(
                    ssid = if (r.SSID.isNullOrBlank()) "<hidden>" else r.SSID,
                    bssid = r.BSSID ?: "",
                    level = WifiManager.calculateSignalLevel(r.level, 101),
                    frequency = r.frequency,
                    channel = channelForFrequency(r.frequency),
                    capabilities = r.capabilities ?: ""
                )
            }.distinctBy { it.bssid }.sortedByDescending { it.level }
            AppState.wifi.clear(); AppState.wifi.addAll(mapped); AppState.changed()
            withContext(Dispatchers.Main) { done(mapped, null) }
        }
    }

    fun connectedWifiSummary(): String {
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return try {
            @Suppress("DEPRECATION") val i = wm.connectionInfo
            "SSID: ${i.ssid}\nBSSID: ${i.bssid}\nRSSI: ${i.rssi} dBm\nLink: ${i.linkSpeed} Mbps\nFrequency: ${i.frequency} MHz"
        } catch (e: Exception) { "Wi-Fi info unavailable: ${e.message}" }
    }

    private fun hostsForCidr(cidr: String): List<String> {
        val parts = cidr.trim().split('/')
        val ip = parts[0]
        val prefix = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(16, 30) ?: 24
        val bytes = ip.split('.').mapNotNull { it.toIntOrNull() }
        if (bytes.size != 4) return emptyList()
        val base = ((bytes[0].toLong() shl 24) or (bytes[1].toLong() shl 16) or (bytes[2].toLong() shl 8) or bytes[3].toLong()) and 0xffffffffL
        val mask = if (prefix == 0) 0 else (0xffffffffL shl (32 - prefix)) and 0xffffffffL
        val network = base and mask
        val count = 2.0.pow((32 - prefix).toDouble()).toLong().coerceAtMost(514)
        val first = if (count > 2) 1 else 0
        val last = if (count > 2) count - 1 else count
        return (first until last).map { n -> longToIp((network + n) and 0xffffffffL) }
    }

    private fun parseNeighbors(raw: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        raw.lineSequence().forEach { line ->
            val p = line.trim().split(Regex("\\s+"))
            val ip = p.firstOrNull() ?: return@forEach
            val idx = p.indexOf("lladdr")
            if (idx >= 0 && idx + 1 < p.size) map[ip] = p[idx + 1]
        }
        return map
    }

    private fun isLocallyAdministeredMac(mac: String): Boolean {
        val first = mac.substringBefore(':').toIntOrNull(16) ?: return false
        return first and 0x02 != 0
    }

    private fun channelForFrequency(freq: Int): Int = when {
        freq in 2412..2472 -> (freq - 2407) / 5
        freq == 2484 -> 14
        freq in 5000..5895 -> (freq - 5000) / 5
        freq in 5955..7115 -> (freq - 5950) / 5
        else -> 0
    }

    private fun command(cmd: String): String {
        return try {
            val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
            val out = BufferedReader(InputStreamReader(p.inputStream)).readText().trim()
            p.waitFor()
            if (out.isBlank()) "No output returned by Android." else out
        } catch (e: Exception) { "Command unavailable: ${e.message}" }
    }

    private fun shellSafe(v: String): String = v.filter { it.isLetterOrDigit() || it in ".:-_" }
    private fun longToIp(v: Long) = "${(v shr 24) and 255}.${(v shr 16) and 255}.${(v shr 8) and 255}.${v and 255}"
    private fun ipv4Number(ip: String): Long = ip.split('.').fold(0L) { a, s -> (a shl 8) + (s.toLongOrNull() ?: 0L) }
}
