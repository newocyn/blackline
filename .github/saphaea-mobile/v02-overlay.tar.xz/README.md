# Saphaea Inspector Mobile 0.2 Alpha

Android counterpart to Saphaea Inspector focused on authorized network diagnostics and web debugging.

## v0.2 focus
- Deeper LAN device fingerprints: reachability, common services, banners, HTTP server/title hints, SSDP/UPnP, platform/role/exposure hints, MAC neighbor data when Android exposes it.
- Deeper packet decoding: IPv4/IPv6, TCP flags/sequence/window, UDP, ICMP, DNS/mDNS questions, HTTP request lines/Host, TLS SNI, QUIC/DHCP/SSDP/SSH/SMB/RDP/MQTT classification, payload + hex previews.
- Expanded Analyze workspace: application protocols, transports, endpoints, ports, conversations, decoded names, packet signals, device inventory, Wi-Fi posture and web observations.
- Quick HTTP requests: GET, HEAD, OPTIONS, robots.txt and editable POST JSON template.
- Device cards can jump directly to a quick HTTP request.

## Android capture note
Raw VPN capture is currently a short diagnostic capture mode. The app decodes packets delivered to its VPN interface but v0.2 does not yet contain a full userspace forwarding engine, so normal traffic can pause while raw capture is active.
